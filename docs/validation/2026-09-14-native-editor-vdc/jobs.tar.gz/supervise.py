import hashlib,json,os,pathlib,subprocess,sys,time,traceback
root=pathlib.Path(sys.argv[1]);q=pathlib.Path(sys.argv[2]);label=sys.argv[3];command=sys.argv[4:]
expected=json.loads((q/'inputs.json').read_text());status=dict(terminal=False,passed=False,started=time.time(),pid=os.getpid(),cwd=str(root),command=command,physical_hardware_io=False)
p=q/(label+'.status.json')
def save():
 t=p.with_suffix('.tmp');t.write_text(json.dumps(status,indent=2)+'\n');t.replace(p)
def changed():return [name for name,h in expected.items() if not (root/name).is_file() or hashlib.sha256((root/name).read_bytes()).hexdigest()!=h]
save()
try:
 assert not changed(),'inputs changed before start'
 with (q/(label+'.log')).open('w') as log:result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 drift=changed();status.update(exit_code=result.returncode,inputs_unchanged=not drift,changed_inputs=drift,passed=result.returncode==0 and not drift)
except BaseException as e:status.update(exit_code=None,error=repr(e),traceback=traceback.format_exc())
status.update(terminal=True,finished=time.time());save()

sys.exit(0 if status["passed"] else 1)
