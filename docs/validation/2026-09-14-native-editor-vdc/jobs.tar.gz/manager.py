import concurrent.futures,json,os,pathlib,subprocess,sys,time
root,q=map(pathlib.Path,sys.argv[1:3]);kind=sys.argv[3]
commands=json.loads((q/('commands.json' if kind=='cpu' else 'vice-commands.json')).read_text())
state=dict(terminal=False,pid=os.getpid(),started=time.time(),kind=kind,jobs={})
path=q/(kind+'-manager.json')
def save():
 temp=path.with_suffix('.tmp');temp.write_text(json.dumps(state,indent=2)+'\n');temp.replace(path)
def run(item):
 name,command=item
 return name,subprocess.run(['/usr/bin/python3','-B',str(q/'supervise.py'),str(root),str(q),name,*command]).returncode
save()
with concurrent.futures.ThreadPoolExecutor(max_workers=4 if kind=='cpu' else 1) as pool:
 for name,code in pool.map(run,commands.items()):state['jobs'][name]=code;save()
state.update(terminal=True,finished=time.time());save()
