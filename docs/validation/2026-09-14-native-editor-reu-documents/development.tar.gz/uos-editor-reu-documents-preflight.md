# REU document backing preflight — 2026-09-14

Read-only follow-up to Editor VDC; production remains frozen for that milestone.
No REU document allocator or service operation has been implemented.

The provider src/native/vdc-service.asm currently exposes operations0..5:
empty/status, open, redraw, pointer, close, status. Its operation1 rejects
vd_phase|ru_active|ru_probe_live, and the client vd_open rejects any bk_state.
The bank-1 component owns the single foreground REU arena used for snapshots.
A second independent ru_open in Editor would collide with that arena.

VDC vs_alloc opens ru_open, allocates its snapshot in4KiB units, and retains
an8-byte token including a4-byte arena cookie. vs_free frees the snapshot;
vs_close calls ru_close, which refuses live records. The parent vd_close then
unconditionally bk_close's the provider. This couples screen and arena life:
adding document allocations alone would prevent closing the display, and
unloading the provider would discard their allocation metadata.

A viable service extension needs separate display and document leases on one
arena, explicit checked allocate/read/write/free operations, and a provider
lifetime lasting until every document/backup/probe allocation is released.
Reopening VDC with existing documents must reuse the live arena, not reprobe or
reinitialize it. Refusal and recovery must retain every original byte; the
provider cannot be unloaded while an uncertain transfer/cookie/cleanup exists.
The service should become a reusable memory facility, with a future scheduling
contract, rather than creating a third private heap in an application.

Current document contexts each occupy128 bytes:24 four-byte chunk tokens at
16..111 and spare112..127. Two contexts implement transactional Open. REU
backing needs either an explicit per-chunk backing bitmap plus retained arena
cookie, or a versioned shared handle representation. Preserve the existing
RAM token checks and 512-byte transfers. Do not interpret an arbitrary token
as REU merely because its RAM lookup failed. RAM and REU owners/generations
must remain distinct and checked before reading or changing logical bytes.

The REU arena has32 records. Two full24-chunk documents plus the VDC snapshot
would exceed that descriptor count even on a large REU; decide whether to
expand its table or allocate larger logical extents before claiming large
transactional Open. Current document limit24x4096=96KiB also needs an explicit
roadmap beyond that initial backing migration. Allocate-before-edit, failed
Open rollback, partial replacement counts and verified exclusive Save As must
remain unchanged from the byte model.

Qualification should establish a document over64KiB with controls active on
both displays, original/save/reopen bytes, picker round trips with REU leases,
RAM fallback,128KiB..16MiB configurations, allocation/cookie/DMA failures,
retained VDC recovery with documents still present, exact unrelated REU bytes,
and all owners released on final exit. This work is still pending.
