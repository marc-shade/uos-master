import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

SP=Path('/var/tmp/arc-scratch/uos-editor-reu-documents-current.json')
s=json.loads(SP.read_text());root=Path(s['frozen']);q=Path(s['qualification'])
repo=Path('/home/marc/geos128/uos');scratch=SP.parent
out=Path(s['candidate'])/'docs/validation/2026-09-14-native-editor-reu-documents'
assert not (out/'SHA256SUMS').exists(), 'sealed records are immutable'
digest=lambda data:hashlib.sha256(data).hexdigest()
def dump(name,value):(out/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def archive(name,files):
    manifest={}
    with (out/(name+'.tar.gz')).open('wb') as raw:
        with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
            with tarfile.open(fileobj=gz,mode='w') as tar:
                for key,value in sorted(files.items()):
                    data=value.read_bytes() if isinstance(value,Path) else value
                    info=tarfile.TarInfo(key);info.size=len(data);info.mode=0o644
                    tar.addfile(info,io.BytesIO(data));manifest[key]=dict(bytes=len(data),sha256=digest(data))
    dump(name+'-files.json',manifest)
    print('archived',name,len(files),flush=True)

inputs=json.loads((q/'inputs.json').read_text());production=json.loads((q/'production.json').read_text())
assert len(inputs)==734 and len(production)==211
assert all(digest((root/p).read_bytes())==h for p,h in inputs.items())
assert all(inputs[p]==h for p,h in production.items())
jobs={};executions={};execution_files={};jobfiles={};outputs={}
for job in s['development']:
    name=job['label']
    if name.startswith(('dev1-','dev2-')) or name=='dev4-vice-large':continue
    status_path=Path(job['status']);status=json.loads(status_path.read_text())
    assert status['terminal'] and status['passed'] and status['exit_code']==0 and status['inputs_unchanged'],name
    assert status['physical_hardware_io'] is False and status['cwd']==job['snapshot']
    for pid in (status['pid'],status['child_pid']):
        proc=Path('/proc')/str(pid)
        assert not proc.exists() or proc.joinpath('stat').read_text().split()[2]=='Z',pid
    snapshot=Path(job['snapshot']);generation=name.split('-')[0]
    manifest_path=status_path.with_name(status_path.name.replace('.status.','.inputs.'))
    manifest=json.loads(manifest_path.read_text())
    assert all(digest((snapshot/p).read_bytes())==h for p,h in manifest.items())
    assert all(manifest.get(p,h)==h and digest((snapshot/p).read_bytes())==h for p,h in production.items())
    actual={p.relative_to(snapshot).as_posix():digest(p.read_bytes()) for p in snapshot.rglob('*')
            if p.is_file() and p.suffix in ('.py','.inc','.asm','.prg','.d64','.d81','.bin')}
    assert actual==manifest
    if generation not in executions:
        executions[generation]=dict(root=str(snapshot),inputs=manifest,production=production,jobs=[])
        execution_files.update({generation+'/'+p:snapshot/p for p in manifest|production})
    assert executions[generation]['inputs']==manifest
    executions[generation]['jobs'].append(name)
    jobs[name]=status
    for suffix in ('status.json','inputs.json','report.json','log'):
        path=scratch/('uos-editor-reu-documents-'+name+'.'+suffix)
        if path.exists():jobfiles[name+'.'+suffix]=path
    if '--report' in status['command']:
        report_path=Path(status['command'][status['command'].index('--report')+1])
        report=json.loads(report_path.read_text());assert report['passed'] and report['physical_hardware_io'] is False
        if 'work' in report:
            folder=Path(report['work'])
            outputs.update({name+'/'+p.relative_to(folder).as_posix():p for p in folder.rglob('*') if p.is_file()})
    else:
        log=jobfiles[name+'.log'].read_text();folder=Path(log.split('Native pointer VICE: ')[1].splitlines()[0])
        report=json.loads((folder/'report.json').read_text())
        assert report['passed'] and report['all_host_processes_terminal']
        outputs.update({name+'/'+p.relative_to(folder).as_posix():p for p in folder.rglob('*') if p.is_file()})
assert len(jobs)==28 and len(executions)==6
for p in q.iterdir():
    if p.is_file():jobfiles[p.name]=p
build=json.loads((q/'build.json').read_text());assert build['passed'] and len(build['images'])==34
rebuilt=Path(build['root'])
assert all(digest((rebuilt/p).read_bytes())==inputs[p]==h for p,h in build['images'].items())
out.mkdir(parents=True,exist_ok=True)
archive('inputs',{p:root/p for p in inputs})
archive('executions',execution_files)
dump('executions.json',executions);dump('jobs.json',jobs)
archive('jobs',jobfiles);archive('outputs',outputs)
archive('rebuilt-images',{p:rebuilt/p for p in build['images']})
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==s['base']
subprocess.run(['git','diff','--quiet','HEAD','--'],cwd=repo,check=True)
assert all(digest((repo/p).read_bytes())==h for p,h in s['protected'].items())
archive('parent-images',{p:repo/p for p in build['images']})
development={p.name:p for p in scratch.glob('uos-editor-reu-documents-*')
             if p.is_file() and p.suffix in ('.json','.log','.md','.py')}
archive('development',development)
tracked=set(subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0'))
untracked=[p for p in inputs if p not in tracked]
ignored=subprocess.run(['git','check-ignore','--stdin','-z'],cwd=repo,input='\0'.join(untracked).encode()+b'\0',capture_output=True)
assert ignored.returncode in (0,1)
ignored=set(ignored.stdout.decode().split('\0'));changes={}
for p,h in inputs.items():
    if p in ignored or p.startswith('target/native-desktop/claude-build/'):continue
    before=digest((repo/p).read_bytes()) if (repo/p).exists() else None
    if before!=h:changes[p]=dict(before=before,after=h)
assert set(changes).isdisjoint(s['protected'])
dump('changes.json',changes)
rom=Path('/usr/share/vice/C128/kernal-318020-05.bin')
dump('provenance.json',dict(base=s['base'],previous_seal=s['previous_seal'],physical_hardware_io=False,
    base_signature='G phoenix-agent@2acrestudios.com',production=s['tested_production_identity'],
    runtime_jobs=28,independent_builds=1,execution_generations=sorted(executions),
    excluded_development_jobs=[j['label'] for j in s['development'] if j['label'] not in jobs],
    kernal_rom=dict(name=rom.name,bytes=rom.stat().st_size,sha256=digest(rom.read_bytes()),redistributed=False),
    tools={name:subprocess.run(command,text=True,capture_output=True,check=True).stdout.splitlines()[0] for name,command in {
        'cc':['cc','--version'],'64tass':['64tass','--version'],'x128':['x128','--version']}.items()}))
s.update(record=str(out),apply_input_paths=sorted(changes),stage='REU document runtime and rebuild checks passed; record awaiting offline audit and seal')
SP.write_text(json.dumps(s,indent=2)+'\n')
print(json.dumps(dict(record=str(out),changes=len(changes),inputs=len(inputs),runtime_jobs=len(jobs)),indent=2))
