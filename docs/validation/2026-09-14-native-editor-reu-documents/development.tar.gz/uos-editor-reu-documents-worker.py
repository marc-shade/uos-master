import json,subprocess,sys,time,os
from pathlib import Path
plan=Path(sys.argv[1]);data=json.loads(plan.read_text());status=plan.with_suffix('.status.json')
state=dict(pid=os.getpid(),terminal=False,current=None,completed=[],passed=True)
def save():
    temp=status.with_suffix('.tmp');temp.write_text(json.dumps(state,indent=2)+'\n');temp.replace(status)
save()
try:
    for job in data['jobs']:
        state['current']=job['label'];save()
        child=subprocess.Popen(job['command'],stdin=subprocess.DEVNULL)
        state['child_pid']=child.pid;save();code=child.wait()
        result=json.loads(Path(job['status']).read_text())
        state['completed'].append(dict(label=job['label'],passed=result['passed'],terminal=result['terminal']))
        state['passed'] &= code==0 and result['terminal'] and result['passed'];save()
finally:
    state.update(terminal=True,current=None,finished=time.time());save()
