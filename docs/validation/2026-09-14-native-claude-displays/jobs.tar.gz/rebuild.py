import hashlib,json,shutil,subprocess
from pathlib import Path
s=json.loads(Path('/var/tmp/arc-scratch/uos-claude-displays-current.json').read_text())
root=Path(s['frozen']);q=Path(s['qualification']);rebuilt=Path(s['rebuild'])
inputs=json.loads((q/'inputs.json').read_text())
for n in inputs:
 target=rebuilt/n;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/n,target)
with (q/'rebuild-command.log').open('w') as log:
 result=subprocess.run(['/usr/bin/python3','-B','build-native-desktop.py'],cwd=rebuilt,stdout=log,stderr=subprocess.STDOUT)
assert result.returncode==0,result.returncode
images={n:hashlib.sha256((rebuilt/n).read_bytes()).hexdigest() for n in inputs if n.startswith(('target/native/','target/native-desktop/')) and Path(n).suffix in ('.prg','.d64','.d81')}
assert len(images)==34 and all(h==inputs[n] for n,h in images.items())
source={n:hashlib.sha256((rebuilt/n).read_bytes()).hexdigest() for n in inputs if n.startswith('src/')}
assert all(h==inputs[n] for n,h in source.items()),'generated source changed'
(q/'build.json').write_text(json.dumps(dict(passed=True,root=str(rebuilt),images=images,generated_source_unchanged=True),indent=2)+'\n')
print('PASS: all 34 native programs/disks reproduce exactly; generated source matches',flush=True)
