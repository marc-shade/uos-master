import sys
from collections import deque
sys.path[:0]=['/var/tmp/arc-scratch/uos-claude-displays-dev1-6udcnwg2/tests','/var/tmp/arc-scratch/uos-claude-displays-dev1-6udcnwg2']
from py65.devices.mpu6502 import MPU
from ci_native_claude_gui import GraphicalClient
trace=deque(maxlen=25);original=MPU.step
def step(cpu):
 trace.append((cpu.pc,cpu.sp,cpu.a,cpu.x,cpu.y))
 result=original(cpu)
 if cpu.pc==0x1730:
  print('TRACE',*[tuple(hex(n) for n in row) for row in trace],sep='\n',flush=True)
  print('stack',bytes(cpu.memory[0x100+i] for i in range(256)).hex(),flush=True)
  raise RuntimeError('first bad target')
 return result
MPU.step=step
c=GraphicalClient.__new__(GraphicalClient)
try:GraphicalClient.__init__(c)
except BaseException as e:
 print(repr(e),flush=True)
 for name in ('cg_panel','cg_panel_row','cg_row','cg_view','cg_column','cg_glyph_write','cg_glyph_store','cg_vdc_glyph','cg_glyph_next','cg_source','cg_unpack'):
  at=c.symbol(name);print(name,hex(at),c.ram[at],flush=True)
