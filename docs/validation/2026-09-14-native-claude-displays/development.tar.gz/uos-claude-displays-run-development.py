import hashlib,json,os,signal,subprocess,sys,time,traceback
from pathlib import Path

root=Path(sys.argv[1]);label=sys.argv[2];command=sys.argv[3:]
folder=Path('/var/tmp/arc-scratch');prefix=folder/('uos-claude-displays-'+label)
status_path=prefix.with_suffix('.status.json')
assert not status_path.exists(),'preserve prior attempts'
status=dict(terminal=False,passed=False,started=time.time(),pid=os.getpid(),cwd=str(root),command=command,physical_hardware_io=False)
def save():
    temporary=status_path.with_suffix('.tmp')
    temporary.write_text(json.dumps(status,indent=2)+'\n');temporary.replace(status_path)
def hashes():
    return {p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
        for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
child=None
def interrupted(signum,frame):
    status['signal']=signum
    if child is not None and child.poll() is None:child.terminate()
    raise SystemExit(128+signum)
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
save();before=hashes();prefix.with_suffix('.inputs.json').write_text(json.dumps(before,indent=2)+'\n')
try:
    with prefix.with_suffix('.log').open('w') as log:
        child=subprocess.Popen(command,cwd=root,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
        status['child_pid']=child.pid;save();code=child.wait()
    after=hashes();status.update(exit_code=code,inputs_unchanged=before==after,passed=code==0 and before==after)
except BaseException as error:
    status.update(error=repr(error),traceback=traceback.format_exc())
    if child is not None and child.poll() is None:
        child.terminate()
        try:child.wait(timeout=10)
        except subprocess.TimeoutExpired:child.kill();child.wait()
finally:
    status.update(terminal=True,finished=time.time());save()
