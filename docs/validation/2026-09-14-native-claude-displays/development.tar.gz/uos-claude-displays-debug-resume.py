import json,sys,time
sys.path[:0]=['/var/tmp/arc-scratch/uos-claude-displays-dev1-6udcnwg2/tests','/var/tmp/arc-scratch/uos-claude-displays-dev1-6udcnwg2']
from ci_native_claude_gui import GraphicalClient
c=GraphicalClient.__new__(GraphicalClient)
try:GraphicalClient.__init__(c)
except BaseException as e:
 print('initial failure',repr(e),flush=True)
 for name in ('native_entry','_main','_tm_begin','_tm_run','_tm_error','_tm_live','cg_error','cg_bitmap','cg_font_ram'):
  at=c.symbol(name);print(name,hex(at),c.ram[at],flush=True)
 print('pc,sp',hex(c.cpu.pc),hex(c.cpu.sp),'Nowner',c.ram[0x3d20], 'config',hex(c.m.bus.config),'ready,busy',list(c.ram[0x3d11:0x3d13]),'borrowed',c.borrowed is not None,flush=True)
 c.loop()
 print('resumed successfully',hex(c.cpu.pc),flush=True)
else:print('initial success',flush=True)
