import json,subprocess,sys,time
from pathlib import Path
spec=json.loads(Path(sys.argv[1]).read_text())
while not json.loads(Path(spec['wait']).read_text()).get('terminal'):time.sleep(1)
for command in spec['commands']:subprocess.run(command,check=True)
