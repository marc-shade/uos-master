import time
from pathlib import Path
import json
previous=Path('/var/tmp/arc-scratch/uos-ultimate-vdc-jobs-nqugac9t/vice-manager.json')
while not previous.exists():time.sleep(1)
assert json.loads(previous.read_text())['terminal']
import json,subprocess
from pathlib import Path
root='/var/tmp/arc-scratch/uos-ultimate-vdc-final-7v45flac';q=Path('/var/tmp/arc-scratch/uos-ultimate-vdc-final-jobs-3py7b0zn')
for name,command in json.loads((q/'vice-commands.json').read_text()).items():
 subprocess.run(['/usr/bin/python3','-B',str(q/'supervise.py'),root,str(q),name,*command],check=True)
(q/'vice-manager.json').write_text(json.dumps(dict(terminal=True))+'\n')
