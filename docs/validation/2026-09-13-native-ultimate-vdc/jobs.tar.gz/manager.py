import concurrent.futures,json,subprocess
from pathlib import Path
root='/var/tmp/arc-scratch/uos-ultimate-vdc-final-7v45flac';q=Path('/var/tmp/arc-scratch/uos-ultimate-vdc-final-jobs-3py7b0zn')
jobs=json.loads((q/'commands.json').read_text())
def run(item):
 name,command=item
 return subprocess.run(['/usr/bin/python3','-B',str(q/'supervise.py'),root,str(q),name,*command]).returncode
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 results=list(pool.map(run,jobs.items()))
(q/'manager.json').write_text(json.dumps(dict(terminal=True,supervisors_returned=results))+'\n')
