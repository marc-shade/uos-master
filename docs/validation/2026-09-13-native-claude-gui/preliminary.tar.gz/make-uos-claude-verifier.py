from pathlib import Path
old=Path('/var/tmp/arc-scratch/uos-picker-verify.py').read_text()
head='''#!/usr/bin/env python3
"""Offline audit of the frozen Claude frame and complete native suite workflows."""
import hashlib,json,re,sys,tarfile,tempfile
from pathlib import Path,PurePosixPath
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
read=lambda name:json.loads((ROOT/name).read_text())
from capture_audit import captures

def audit():
    if (ROOT/'SHA256SUMS').exists():
        for line in (ROOT/'SHA256SUMS').read_text().splitlines():
            digest,name=line.split('  ',1);assert sha((ROOT/name).read_bytes())==digest,name
    archives=read('archives.json')
    with tempfile.TemporaryDirectory(prefix='uos-claude-audit-') as temporary:
        temp=Path(temporary)
        for label,info in archives.items():
            archive=ROOT/info['archive'];assert sha(archive.read_bytes())==info['sha256']
            manifest=read(info['manifest']);assert len(manifest)==info['payload_files']
            assert sum(row['bytes'] for row in manifest.values())==info['payload_bytes']
            with tarfile.open(archive,'r:gz') as tar:
                members=tar.getmembers();assert len(members)==len(manifest)
                assert {m.name for m in members}==set(manifest)
                for member in members:
                    name=PurePosixPath(member.name)
                    assert member.isfile() and not name.is_absolute() and '..' not in name.parts
                    raw=tar.extractfile(member).read();row=manifest[member.name]
                    assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
                    target=temp/label/member.name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
        source=temp/'inputs';inputs=read('inputs-files.json')
        sys.path[:0]=[str(source),str(source/'tests')]
        from native_image import validate
        from native_module import validate as validate_module
        from native_browser_check import disk_records
        from native_files_scene import browser_surface as files_surface,browser_console as files_console,copy_surface as files_copy_surface,copy_console as files_copy_console
        from native_files_check import exact_d64_files
        from native_calc_scene import surface as calc_surface
        from native_editor_scene import surface as editor_surface,console as editor_console
        from native_picker_scene import surface as picker_surface,console as picker_console
        from native_capture import calculator_screen
        from native_pointer_check import pixels,surface_pixels,check_canvas
        from launcher_scene import surface,console
        from paint_scene import surface as paint_surface,console as paint_console,MESSAGES
        from native_paint_format import encode,decode
        from native_running_layout import RunningLayout
        from native_controls_check import panel_screen,absent_body
        from native_controls_scene import surface as controls_surface
        from native_claude_scene import surface as claude_surface
        from native_claude_check import landing_screen,waiting_panel
        from native_suite_workflow import terminal_screen
        rebuilt=read('main-rebuild.json');frozen=read('frozen-rebuild.json')
        assert rebuilt['passed'] and frozen['passed'] and rebuilt['images']==frozen['images']
        assert rebuilt['build_exit_code']==frozen['build_exit_code']==0 and len(rebuilt['images'])==24
        for name,digest in rebuilt['images'].items():assert inputs[name]['sha256']==digest,name
        base=read('base-images.json')
        assert {name for name,digest in base.items() if inputs[name]['sha256']!=digest}=={
            'target/native-desktop/claude.prg','target/native-desktop/uos128.d64','target/native-desktop/workspace.d64'}
        assert (ROOT/'base-commit.txt').read_text().strip()=='2f24a31bc7f04d4582d92fd7e0bf9e3750ec9749'
        app=validate((source/'target/native-desktop/claude.prg').read_bytes())
        assert (app['bytes'],app['pages'],app['entry'],app['title'])==(11057,75,0x6020,'CLAUDE')
        for core,parts in (('editor',('edpick','edfind')),('files',('fspick','fsview'))):
            for part in parts:validate_module((source/f'target/native-desktop/{part}.prg').read_bytes(),(source/f'target/native-desktop/{core}.prg').read_bytes())
        deployment=json.loads((source/'target/native-desktop/deployment.json').read_text())
        for disk in ('uos128.d64','workspace.d64'):
            files=exact_d64_files((source/'target/native-desktop'/disk).read_bytes())
            assert len(files)==12
            for name,filename in deployment['disk_entries'].items():
                path=source/('target/native' if name=='u' and disk=='workspace.d64' else 'target/native-desktop')/filename
                assert files[name.upper().encode()]==(2,path.read_bytes())
        provenance=read('provenance.json');runs=read('qualified-runs.json')
        for name,run in runs.items():
            status,config=run['status'],run['config']
            assert status['terminal'] and status['exit_code']==0
            assert sha((source/config['driver']).read_bytes())==config['source_sha256'][config['driver']]
            for path in ('src/native/claude/main.c','src/native/claude/c128hw.s','src/native/claude/gui.asm','src/native/claude/scene.inc','src/native/claude/uos.cfg','build-native-claude.py','native_claude_scene.py','src/native/input/key-filter.inc'):
                assert inputs[path]['sha256']==config['source_sha256'][path],(name,path)
        cpu_cases=host_cases=0
        for name in provenance['cpu_jobs']+provenance['host_jobs']:
            report=json.loads((temp/'app-cpu'/(name+'.json')).read_text());assert report['passed'] and not report['physical_hardware_io']
            if name in provenance['cpu_jobs']:cpu_cases+=len(report['cases'])
            else:host_cases+=len(report['cases'])
            for path,digest in report.get('images',{}).items():assert inputs[path]['sha256']==digest
        stream=json.loads((temp/'app-cpu/cpu-stream-v6.json').read_text())['cases'][0]
        assert stream['bytes_received']==3228 and stream['peak_ring']<=192 and stream['interrupts_during_transfers']>0
        assert 63 in stream['interrupted_maps']
        running=RunningLayout(source,image_dir=source/'target/native-desktop')
        def resident(folder):
            for prefix in ('resident-boot','resident-return'):
                data={name:(folder/(prefix+'-'+name+'.bin')).read_bytes() for name in running.regions}
                assert running.compare(data)['passed']
        def claude_frames(folder,report):
            count=0
            for row in report['claude_frames']:
                name=row['label'];expected=row['expected'];panel=bytes.fromhex(row['panel_hex'])
                if expected['live']:assert panel==waiting_panel(connected=True)
                else:assert panel in (landing_screen(40),landing_screen(40,2))
                assert (folder/(name+'-panel.bin')).read_bytes()==panel
                glyphs=(folder/(name+'-font.bin')).read_bytes();assert len(glyphs)==4096
                wanted=claude_surface(panel,b'\\1'*1000,glyphs,**expected)
                assert (folder/(name+'-surface.bin')).read_bytes()==wanted and sha(wanted)==row['surface_sha256']
                assert check_canvas((folder/(name+'-canvas.bin')).read_bytes(),surface_pixels(wanted,*row['position'],visible=row.get('pointer_visible',True)))==row['rectangle']
                count+=1
            return count
'''
a=old.index('        blank=bytes(8192)');b=old.index("        folder=temp/'serial';",a)
body=old[a:b]
body=body.replace('editor_only=False)','editor_only=False,claude_only=False)')
body=body.replace('assert len(report[\'picker_frames\'])==4','assert len(report[\'picker_frames\'])==5')
body=body.replace("                    excluded={b'PAINTPIC'} if name=='files-copy-return' else {b'PAINTPIC',b'FSCOPY'}\n                    assert entries==[entry for entry in final_entries if entry['name'] not in excluded]",'                    assert entries==final_entries')
body=body.replace("                    assert name=='files-data-picker' and entries==disk_records((folder/'initial-data-9.d64').read_bytes())==[]", "                    if name=='files-data-picker':assert entries==[]\n                    else:\n                        data_entries=[dict(e,app=False) for e in disk_records((folder/'data-9.d64').read_bytes())]\n                        if name=='paint-save-destination':data_entries=[e for e in data_entries if e['name']!=b'PAINTPIC']\n                        assert entries==data_entries")
body=body.replace("            keys=(folder/'keys-before.bin').read_bytes();", "            assert len(report['claude_frames'])==4\n            frames+=claude_frames(folder,report)\n            keys=(folder/'keys-before.bin').read_bytes();")
body=body.replace("            picture=disk.pop(b'PAINTPIC');", "            data_disk=exact_d64_files((folder/'data-9.d64').read_bytes())\n            assert report['paint_destination_device']==9\n            picture=data_disk.pop(b'PAINTPIC');")
body=body.replace("            data_disk=exact_d64_files((folder/'data-9.d64').read_bytes())\n            assert exact_d64_files", "            assert exact_d64_files")
tail='''
        for label,host_exit in (('serial40',False),('serial80',True)):
            folder=temp/label;report=json.loads((folder/'report.json').read_text())
            assert report['passed'] and not report['physical_hardware_io'] and report['host_exit_code']==0
            assert report['options']['mouse'] and report['options']['eighty']==host_exit and report['options']['host_exit']==host_exit
            assert report['mouse_enabled_after_claude_launch'] and len(report['private_x_windows'])==2
            assert (folder/'run.py').read_bytes()==(source/'tests/ci_native_claude_iec.py').read_bytes()
            assert (folder/'suite.d64').read_bytes()==(source/'target/native-desktop/uos128.d64').read_bytes()
            for name,digest in report['images'].items():assert inputs['target/native-desktop/'+name]['sha256']==digest
            totals[label]=captures(folder,dict(captures=report['cpu_captures'],paused_capture_batches=report['cpu_capture_batches']))
            assert not totals[label]['rejected'] and len(report['claude_frames'])==6
            frames+=claude_frames(folder,report)
            assert (folder/'session-vdc.bin').read_bytes()==terminal_screen(True)
            assert (folder/'returned-desktop-surface.bin').read_bytes()==surface(4)
            assert (folder/'returned-desktop-vdc.bin').read_bytes()==console(80,4)
            assert (folder/'font-after.bin').read_bytes()==(folder/'font-before.bin').read_bytes()
            assert (folder/'nmi-after.bin').read_bytes()==(folder/'nmi-before.bin').read_bytes()
            expected=0 if host_exit else 2
            assert report['close_outcome']==expected and (folder/'close-outcome.bin').read_bytes()==bytes([expected])
            assert report['serial_counters']['_rxDropped']==report['serial_counters']['_rxOverruns']==0
            assert report['serial_counters']['_rxCount']>0 and report['serial_counters']['_nmiCount']>=report['serial_counters']['_rxCount']
            checkpoint=(folder/'close-checkpoint.bin').read_bytes()
            assert checkpoint.hex()==report['close_observation']['checkpoint_hex'] and int.from_bytes(checkpoint[13:17],'little')>0
            assert report['close_observation']['lifetime']=='Claude allocation still live; before native_video_end'
            assert [row['code'] for row in report['rom_keys']]==[255,9,9,13,27]
            assert all(row['keyboard_events']==0 for row in report['mouse_events'])
            assert all(row['after']==(row['before']+1)&65535 for row in report['rom_keys'])
            pages=(folder/'final-heap.bin').read_bytes();assert pages[0x50:0xff]==bytes(175) and pages[0x104:0x1ff]==bytes(251)
        assert all(not row['rejected'] for row in totals.values())
        return dict(passed=True,physical_hardware_io=False,inputs=len(inputs),images=len(rebuilt['images']),
            cpu_cases=cpu_cases,host_cases=host_cases,qualified_processes=len(runs),palette_frames=frames,pixels=frames*64000,
            capture_totals=totals,captures=sum(row['captures'] for row in totals.values()),
            chunks=sum(row['chunks'] for row in totals.values()),borrower_pairs=sum(row['borrower_pairs'] for row in totals.values()),
            archives={label:dict(files=row['payload_files'],bytes=row['payload_bytes']) for label,row in archives.items()})

if __name__=='__main__':print(json.dumps(audit(),indent=2))
'''
result=head+body+tail
import ast;ast.parse(result)
Path('/var/tmp/arc-scratch/uos-claude-gui-verify.py').write_text(result)
print('Wrote',len(result.splitlines()),'lines')
