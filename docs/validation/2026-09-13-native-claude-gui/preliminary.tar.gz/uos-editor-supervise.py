#!/usr/bin/env python3
"""Record a bounded test process through its actual terminal result."""
import json,os,signal,subprocess,sys,time
from pathlib import Path
config=json.loads(Path(sys.argv[1]).read_text());status=Path(config['status'])
record=dict(passed=False,terminal=False,command=config['command'],cwd=config['cwd'],supervisor_pid=os.getpid())
def save():
 temporary=status.with_suffix('.tmp');temporary.write_text(json.dumps(record,indent=2)+'\n');temporary.replace(status)
started=time.monotonic()
with Path(config['log']).open('w') as log:
 process=subprocess.Popen(config['command'],cwd=config['cwd'],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 record['pid']=process.pid;save()
 try:code=process.wait(timeout=config.get('timeout_seconds',3600))
 except subprocess.TimeoutExpired:
  record['timed_out']=True;os.killpg(process.pid,signal.SIGTERM)
  try:code=process.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);code=process.wait()
 record.update(exit_code=code,terminal=True,passed=code==0,elapsed_seconds=round(time.monotonic()-started,3));save()
raise SystemExit(0 if record['passed'] else 1)
