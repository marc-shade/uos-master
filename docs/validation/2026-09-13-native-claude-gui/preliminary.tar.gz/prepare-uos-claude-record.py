"""Freeze only completed Claude qualification processes and their exact inputs."""
import hashlib,json,re,shutil,subprocess,tarfile,tempfile
from pathlib import Path
SCRATCH=Path('/var/tmp/arc-scratch');BASE=Path('/home/marc/geos128/uos')
STATE=SCRATCH/'uos-claude-gui-current.json';s=json.loads(STATE.read_text());C=Path(s['candidate'])
RECORD=C/'docs/validation/2026-09-13-native-claude-gui'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
cpu=['cpu-core-v6','cpu-input-v6','cpu-stream-v6','cpu-fallback-v6','cpu-terminal-v5','cpu-pointer-v5']
host=['host-bridge-v5','host-protocol-v5']
vice=dict(vice40='pointer40-v7',vice80='pointer80-v5',serial40='serial-mouse40-v7',serial80='serial-mouse80-v7',keyboard='keyboard-v7')
qualified={}
folders={}
for name in cpu+host+list(vice.values()):
 config=dict(s['jobs'][name]);status=read(config['status']);assert status['terminal'] and status['exit_code']==0,name
 driver=next(arg for arg in config['command'] if arg.endswith('.py'))
 driver=str(Path(driver).relative_to(C)) if Path(driver).is_absolute() else driver
 config['driver']=driver;assert sha((C/driver).read_bytes())==config['source_sha256'][driver],(name,driver)
 qualified[name]=dict(config=config,status=status)
for label,name in vice.items():
 log=Path(s['jobs'][name]['log']).read_text();folder=Path(log.splitlines()[0].split(': ',1)[1])
 assert read(folder/'report.json')['passed'],label
 folders[label]=folder
assert not RECORD.exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=BASE,text=True).strip()==s['base']
assert not subprocess.check_output(['git','diff','--name-only'],cwd=BASE,text=True)
for name,digest in s['protected_sha256'].items():assert sha((BASE/name).read_bytes())==digest
# Update only the current checkpoint's qualification text, never historical records.
link='validation/2026-09-13-native-claude-gui/README.md'
p=C/'docs/NATIVE-CLAUDE-GUI.md';p.write_text(p.read_text().replace('Software qualification is in progress.',f'The [software qualification]({link}) passes.'))
for name,marker in [('docs/NATIVE-PLATFORM-NEXT.md','The [Claude frame]'),('docs/IMPLEMENTATION-ROADMAP.md','The [Claude graphical companion]')]:
 p=C/name;text=p.read_text();at=text.index(marker)
 p.write_text(text[:at]+text[at:].replace('Software qualification is in progress',f'The [software qualification]({link}) passes',1))
RECORD.mkdir(parents=True)
def write(name,value):(RECORD/name).write_text(json.dumps(value,indent=2)+'\n')
archives={}
def archive(label,paths):
 manifest={}
 with tarfile.open(RECORD/(label+'.tar.gz'),'w:gz') as tar:
  for name,path in sorted(paths.items()):
   assert path.is_file() and not path.is_symlink(),path
   raw=path.read_bytes();manifest[name]=dict(bytes=len(raw),sha256=sha(raw));tar.add(path,arcname=name,recursive=False)
 write(label+'-files.json',manifest)
 archives[label]=dict(archive=label+'.tar.gz',manifest=label+'-files.json',sha256=sha((RECORD/(label+'.tar.gz')).read_bytes()),payload_files=len(paths),payload_bytes=sum(row['bytes'] for row in manifest.values()))
 write('archives.json',archives)
 return manifest
files=lambda folder:{str(p.relative_to(folder)):p for p in folder.rglob('*') if p.is_file()}
names=set(s['input_paths'])|set(s['new_source_paths'])
for directory in ('target/native','target/native-desktop'):
 names.update(str(p.relative_to(C)) for p in (C/directory).iterdir() if p.is_file() and p.suffix in ('.prg','.d64','.json','.lst','.sym','.lbl','.map'))
assert not any(name.startswith('docs/validation/') or name in s['protected_sha256'] for name in names)
inputs=archive('inputs',{name:C/name for name in names})
write('base-images.json',{str(p.relative_to(BASE)):sha(p.read_bytes()) for directory in ('target/native','target/native-desktop') for p in (BASE/directory).iterdir() if p.suffix in ('.prg','.d64')})
(RECORD/'base-commit.txt').write_text(s['base']+'\n')
for label,folder in folders.items():archive(label,files(folder))
app=Path(tempfile.mkdtemp(prefix='uos-claude-qualified-cpu-',dir=SCRATCH))
for name in cpu+host:
 config=qualified[name]['config'];status=qualified[name]['status']
 log=Path(config['log']);shutil.copy2(log,app/(name+'.log'))
 shutil.copy2(config['status'],app/(name+'.status.json'))
 if name=='host-protocol-v5':
  text=log.read_text();assert '30/30 passed' in text
  result=dict(passed=True,physical_hardware_io=False,cases=re.findall(r'^  PASS  (\S+)$',text,re.M));assert len(result['cases'])==30
  (app/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n')
 else:
  source=Path(config['command'][config['command'].index('--report')+1]);assert read(source)['passed']
  shutil.copy2(source,app/(name+'.json'))
archive('app-cpu',files(app))
preliminary={}
for path in SCRATCH.glob('uos-claude-gui-*'):
 if path.is_file() and path.suffix in ('.json','.log','.png','.py'):preliminary[path.name]=path
for config in s['jobs'].values():
 try:folder=Path(Path(config['log']).read_text().splitlines()[0].split(': ',1)[1])
 except (ValueError,IndexError):continue
 if folder not in folders.values() and (folder/'report.json').is_file():
  preliminary.update({folder.name+'/'+name:path for name,path in files(folder).items()})
for name in ('uos-editor-supervise.py','prepare-uos-claude-record.py','make-uos-claude-verifier.py'):
 preliminary[name]=SCRATCH/name
archive('preliminary',preliminary)
write('qualified-runs.json',qualified)
write('provenance.json',dict(base_commit=s['base'],physical_hardware_io=False,pushed=False,cpu_jobs=cpu,host_jobs=host,vice_jobs=vice,
 candidate=str(C),qualified_folders={label:str(p) for label,p in folders.items()},
 notes=['All qualified processes reached terminal exit zero.','Only Claude and the two containing disks differ among 24 native images.',
 'Start host mouse movement after checking cold boot; an initial GTK movement previously selected Paint.',
 'Admit idle observer snapshots before touching borrowed memory; keep every first readback.',
 'Preserve full module copy and Paint image on a separate device-9 data disk.',
 'A preliminary full 40-column run observed invalid zero POT values and the correctly hidden pointer in unchanged Ultimate code; its failed frame is retained.'],
 remaining=['Physical native suite/serial qualification','Authenticated Claude session','VIC-only terminal','VDC bitmap controls','Broader OS and application roadmap']))
shutil.copy2(SCRATCH/'uos-claude-gui-verify.py',RECORD/'verify.py')
previous=BASE/'docs/validation/2026-09-13-native-picker-gui'
for name in ('capture_audit.py','rebuild.py'):shutil.copy2(previous/name,RECORD/name)
shutil.copy2(SCRATCH/'uos-claude-gui-build-v3.log',RECORD/'candidate-build.log')
for original,name in [('claude-landing.png','claude-landing.png'),('claude-connected.png','claude-session.png'),('claude-bottom-panel.png','claude-controls.png')]:
 shutil.copy2(folders['serial40']/original,RECORD/name)
frozen=Path(tempfile.mkdtemp(prefix='uos-claude-frozen-',dir=SCRATCH))
for name in names:
 p=frozen/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(C/name,p)
s.update(record=str(RECORD),frozen=str(frozen),frozen_inputs=len(inputs),qualified_folders={name:str(folder) for name,folder in folders.items()},
 app_cpu_final=str(app),stage='Claude evidence frozen; separate rebuilds and independent audit pending.')
STATE.write_text(json.dumps(s,indent=2)+'\n')
print(json.dumps(dict(record=str(RECORD),frozen=str(frozen),inputs=len(inputs)),indent=2))
