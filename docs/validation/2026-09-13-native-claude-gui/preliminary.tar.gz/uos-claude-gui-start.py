import hashlib,json,subprocess,sys
from pathlib import Path
s=Path('/var/tmp/arc-scratch/uos-claude-gui-current.json');d=json.loads(s.read_text());c=Path(d['candidate']);name=sys.argv[1];assert name.replace('-','').replace('_','').isalnum()
stem=Path('/var/tmp/arc-scratch')/('uos-claude-gui-'+name);assert not Path(str(stem)+'.status.json').exists()
config=dict(command=sys.argv[2:],cwd=str(c),log=str(stem)+'.log',status=str(stem)+'.status.json',timeout_seconds=2400)
p=Path(str(stem)+'.config.json');p.write_text(json.dumps(config,indent=2)+'\n')
with Path(str(stem)+'.supervisor.log').open('w') as log:
 proc=subprocess.Popen(['/usr/bin/python3','-u','-B','/var/tmp/arc-scratch/uos-editor-supervise.py',str(p)],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
d['new_source_paths']=sorted(set(d['new_source_paths'])|{'docs/NATIVE-CLAUDE-GUI.md'})
d.setdefault('jobs',{})[name]=dict(config,supervisor_pid=proc.pid,source_sha256={v:hashlib.sha256((c/v).read_bytes()).hexdigest() for v in d['input_paths']+d['new_source_paths'] if (c/v).is_file()})
s.write_text(json.dumps(d,indent=2)+'\n');print(name,proc.pid)
