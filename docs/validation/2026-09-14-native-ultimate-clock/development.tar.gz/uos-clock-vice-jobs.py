import json,subprocess,time
from pathlib import Path
root=Path('/var/tmp/arc-scratch/uos-clock-vice1-a4rj5h6n')
work=root.parent/(root.name+'-jobs');work.mkdir()
for name,options in [('vice16',['--controls-only','--controls-clock']),('vice64',['--controls-only','--controls-clock','--80col','--vdc64','--d81','--reu-kib','128'])]:
 command=['/home/marc/.venvs/uos-tests/bin/python3','-B','tests/ci_native_pointer_iec.py',*options]
 status=dict(command=command,cwd=str(root),started=time.time())
 path=work/(name+'.status.json')
 with (work/(name+'.log')).open('w') as out:
  p=subprocess.Popen(command,cwd=root,stdout=out,stderr=subprocess.STDOUT);status['pid']=p.pid;path.write_text(json.dumps(status,indent=2)+'\n');code=p.wait()
 status.update(exit_code=code,finished=time.time());path.write_text(json.dumps(status,indent=2)+'\n')
