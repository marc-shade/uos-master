import json,subprocess,time
from pathlib import Path
root=Path('/var/tmp/arc-scratch/uos-clock-workspace-a9ouypar')
s=dict(cwd=str(root),started=time.time(),command=['/home/marc/.venvs/uos-tests/bin/python3','-B','tests/ci_native_controls_workspace.py','--report','/var/tmp/arc-scratch/uos-clock-workspace-a9ouypar.json'])
with Path('/var/tmp/arc-scratch/uos-clock-workspace-a9ouypar.log').open('w') as out:s['exit_code']=subprocess.call(s['command'],cwd=root,stdout=out,stderr=subprocess.STDOUT)
s['finished']=time.time();Path('/var/tmp/arc-scratch/uos-clock-workspace-a9ouypar.status.json').write_text(json.dumps(s,indent=2)+'\n')
