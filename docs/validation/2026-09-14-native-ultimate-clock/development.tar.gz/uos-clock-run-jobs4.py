import concurrent.futures, hashlib, json, os, shutil, subprocess, tempfile, time
from pathlib import Path
state_path=Path('/var/tmp/arc-scratch/uos-ultimate-clock-current.json')
state=json.loads(state_path.read_text());source=Path(state['candidate'])
frozen=Path(tempfile.mkdtemp(prefix='uos-clock-dev4-',dir='/var/tmp/arc-scratch'))
shutil.copytree(source,frozen,dirs_exist_ok=True)
work=Path(tempfile.mkdtemp(prefix='uos-clock-jobs-',dir='/var/tmp/arc-scratch'))
py='/home/marc/.venvs/uos-tests/bin/python3'
jobs=[]
for case in ('input','vdc16','calendar','protocol','vdc64','fault'):
 jobs.append(('clock-'+case,'tests/ci_native_clock.py',['--case',case]))
for case in ('keyboard','mouse','picker','faults','fallback','payloads','cleanup'):
 jobs.append(('gui-'+case,'tests/ci_native_controls_gui.py',['--case',case]))
jobs.insert(2,('workspace','tests/ci_native_controls_workspace.py',[]))
jobs += [('vdc-picker','tests/ci_native_vdc_controls_picker.py',[]),('vdc-reu','tests/ci_native_vdc_controls_reu.py',[]),('vdc-pressure','tests/ci_native_vdc_controls_fallback.py',['--group','memory']),('vdc-core','tests/ci_native_vdc_controls.py',['--group','core'])]
jobs=[job for job in jobs if job[0] in ('clock-input','clock-vdc16','clock-vdc64')]
state.update(dev_frozen=str(frozen),dev_jobs=str(work),dev_supervisor_pid=os.getpid(),dev_jobs_count=len(jobs))
state_path.write_text(json.dumps(state,indent=2)+'\n')
manifest={p.relative_to(frozen).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in frozen.rglob('*') if p.is_file()}
(work/'inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
def run(job):
 label,script,options=job;start=time.time();command=[py,'-B',script,*options,'--report',str(work/(label+'.json'))]
 status=dict(label=label,command=command,cwd=str(frozen),started=start)
 path=work/(label+'.status.json');path.write_text(json.dumps(status,indent=2)+'\n')
 with (work/(label+'.log')).open('w') as output:
  proc=subprocess.Popen(command,cwd=frozen,stdout=output,stderr=subprocess.STDOUT)
  status['pid']=proc.pid;path.write_text(json.dumps(status,indent=2)+'\n')
  code=proc.wait()
 status.update(exit_code=code,finished=time.time(),elapsed=time.time()-start)
 path.write_text(json.dumps(status,indent=2)+'\n')
 return status
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 results=list(pool.map(run,jobs))
(work/'complete.json').write_text(json.dumps(results,indent=2)+'\n')
