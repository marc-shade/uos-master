from pathlib import Path
import hashlib,json,subprocess,time
root=Path('/var/tmp/arc-scratch/uos-clock-rebuild2-t3lwerpx');src=Path('/var/tmp/arc-scratch/uos-ultimate-clock-qul9rf2a')
report=dict(passed=False,started=time.time(),cwd=str(root),command=['python3','-B','build-native-desktop.py'])
with (root.parent/(root.name+'.log')).open('w') as out:
 code=subprocess.call(report['command'],cwd=root,stdout=out,stderr=subprocess.STDOUT)
report['exit_code']=code
if code==0:
 images={}
 for folder in ('native','native-desktop'):
  for p in sorted((src/'target'/folder).rglob('*')):
   if p.suffix not in ('.prg','.d64','.d81'):continue
   name=p.relative_to(src).as_posix();a=hashlib.sha256(p.read_bytes()).hexdigest();b=hashlib.sha256((root/name).read_bytes()).hexdigest();images[name]=dict(candidate=a,rebuild=b)
 report['images']=images;report['passed']=all(v['candidate']==v['rebuild'] for v in images.values())
report['finished']=time.time()
(root.parent/(root.name+'.json')).write_text(json.dumps(report,indent=2)+'\n')
