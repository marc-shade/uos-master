#!/usr/bin/env python3
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
import threading
import time
ROOT=Path('/var/tmp/arc-scratch/uos-native-files-gui-v15-id8xb8mg')
os.nice(10)
OUT=Path(tempfile.mkdtemp(prefix='uos-files-app-cpu-',dir='/var/tmp/arc-scratch'))
PYTHON='/home/marc/.venvs/uos-tests/bin/python3'
jobs=[]
for case in ('keyboard','mouse','picker','fallback','fields','ultimate','modules','longfields','gestures','retained','source','cancel','reservation'):
 jobs.append(dict(name='gui_'+case,script='files_gui',args=['--case',case]))
for case in ('iec','ultimate','faults'):
 jobs.append(dict(name='copy_'+case,script='files_copy',args=['--case',case]))
images={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for folder in ('target/native','target/native-desktop') for p in (ROOT/folder).iterdir() if p.suffix in ('.prg','.d64')}
assert len(images)==24
report=dict(passed=False,physical_hardware_io=False,jobs=jobs,tests={},images=images,all_host_processes_terminal=False)
lock=threading.Lock()
def save():(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(OUT,flush=True);save()
state=Path('/var/tmp/arc-scratch/uos-files-current.json');data=json.loads(state.read_text());data['app_cpu_final']=str(OUT);state.write_text(json.dumps(data,indent=2)+'\n')
def run(job):
 name=job['name'];command=[PYTHON,'-B',str(ROOT/'tests'/('ci_native_'+job['script']+'.py')),*job['args'],'--report',str(OUT/(name+'.json'))]
 started=time.monotonic()
 with (OUT/(name+'.log')).open('w') as log:
  process=subprocess.Popen(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
  code=process.wait()
 with lock:
  report['tests'][name]=dict(command=command,exit_code=code,elapsed_seconds=round(time.monotonic()-started,3),terminal=process.poll() is not None)
  save();print(name,code,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(run,jobs))
report['all_host_processes_terminal']=all(row['terminal'] for row in report['tests'].values())
report['passed']=all(row['exit_code']==0 and json.loads((OUT/(name+'.json')).read_text())['passed'] for name,row in report['tests'].items())
report['images_unchanged']=images=={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in images}
assert report['images_unchanged'];save()
print('PASS' if report['passed'] else 'FAILED',OUT,flush=True)
raise SystemExit(0 if report['passed'] else 1)
