import hashlib,json,shutil,subprocess
from pathlib import Path
root=Path('/var/tmp/arc-scratch/uos-paint-vdc-frozen-udrxdkko');q=Path('/var/tmp/arc-scratch/uos-paint-vdc-jobs-0n6glpr8');rebuilt=Path('/var/tmp/arc-scratch/uos-paint-vdc-rebuild-swgsy_x1')
expected=json.loads((q/'inputs.json').read_text())
for name in expected:
 target=rebuilt/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,target)
with (q/'rebuild-command.log').open('w') as log:
 result=subprocess.run(['/usr/bin/python3','-B','build-native-desktop.py'],cwd=rebuilt,stdout=log,stderr=subprocess.STDOUT)
assert result.returncode==0,result.returncode
paths=[p for p in expected if p.startswith(('target/native/','target/native-desktop/')) and Path(p).suffix in ('.prg','.d64','.d81')]
assert len(paths)==34
images={p:hashlib.sha256((rebuilt/p).read_bytes()).hexdigest() for p in paths}
assert all(h==expected[p] for p,h in images.items())
raw=q/'paint-expanded.prg'
subprocess.run(['64tass','-a','-B',str(rebuilt/'src/native/paint.asm'),'-o',str(raw)],check=True,capture_output=True)
import binascii
body=bytearray(raw.read_bytes());assert body[:8]==b'\x00\x60NAPP\x01\x01' and body[16:18]==bytes(2)
body[16:18]=binascii.crc_hqx(body[2:],65535).to_bytes(2,'little');raw.write_bytes(body)
assert hashlib.sha256(body).hexdigest()==json.loads((root/'target/native-desktop/deployment.json').read_text())['packed_apps']['paint']['raw_sha256']
(q/'build.json').write_text(json.dumps(dict(passed=True,root=str(rebuilt),images=images),indent=2)+'\n')
print('PASS: all 34 native PRG and disk artifacts reproduce exactly',flush=True)
