import concurrent.futures,json,pathlib,subprocess,sys
root,q=map(pathlib.Path,sys.argv[1:]);commands=json.loads((q/'commands.json').read_text())
def run(item):
 name,command=item
 return subprocess.run(['/usr/bin/python3','-B',str(q/'supervise.py'),str(root),str(q),name,*command]).returncode
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,commands.items()))
(q/'manager.json').write_text(json.dumps(dict(terminal=True,supervisors_returned=results))+'\n')
