import json,pathlib,subprocess,sys
root,q=map(pathlib.Path,sys.argv[1:])
for name,command in json.loads((q/'rerun-commands.json').read_text()).items():
 subprocess.run(['/usr/bin/python3','-B',str(q/'supervise.py'),str(root),str(q),name,*command],check=True)
(q/'vice-manager.json').write_text(json.dumps(dict(terminal=True))+'\n')
