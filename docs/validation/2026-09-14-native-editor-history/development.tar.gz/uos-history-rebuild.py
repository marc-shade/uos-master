import hashlib,json,subprocess,time
from pathlib import Path
s=json.loads(Path('/var/tmp/arc-scratch/uos-editor-history-current.json').read_text());root=Path(s['rebuild_root']);src=Path(s['final_root']);h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=dict(passed=False,started=time.time(),cwd=str(root),command=['python3','-B','build-native-desktop.py'],clean_generated_directories=['target/native','target/native-desktop'])
with Path(s['rebuild_log']).open('w') as out:
 p=subprocess.Popen(r['command'],cwd=root,stdout=out,stderr=subprocess.STDOUT);r['pid']=p.pid;r['exit_code']=p.wait()
if not r['exit_code']:
 r['images']={p.relative_to(src).as_posix():dict(candidate=h(p),rebuild=h(root/p.relative_to(src))) for name in ('native','native-desktop') for p in sorted((src/'target'/name).rglob('*')) if p.suffix in ('.prg','.d64','.d81')}
 r['passed']=len(r['images'])==35 and all(v['candidate']==v['rebuild'] for v in r['images'].values())
r['finished']=time.time();Path(s['rebuild_report']).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(dict(passed=r['passed'],images=len(r.get('images',{})),exit_code=r['exit_code'])));raise SystemExit(int(not r['passed']))
