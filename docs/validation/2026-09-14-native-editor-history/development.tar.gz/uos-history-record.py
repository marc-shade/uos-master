import gzip,hashlib,io,json,shutil,subprocess,tarfile,tempfile
from pathlib import Path
SP=Path('/var/tmp/arc-scratch/uos-editor-history-current.json')
s=json.loads(SP.read_text());candidate=Path(s['root']);repo=Path('/home/marc/geos128/uos')
out=candidate/'docs/validation/2026-09-14-native-editor-history'
assert not (out/'SHA256SUMS').exists(),'sealed records are immutable'
out.mkdir(parents=True,exist_ok=True)
digest=lambda b:hashlib.sha256(b).hexdigest()
def dump(name,value):(out/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def manifest(root):return {p.relative_to(root).as_posix():digest(p.read_bytes()) for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and not p.relative_to(root).as_posix().startswith('docs/validation/')}
def archive(name,files):
    table={}
    with (out/(name+'.tar.gz')).open('wb') as raw:
        with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
            with tarfile.open(fileobj=gz,mode='w') as tar:
                for key,value in sorted(files.items()):
                    data=value.read_bytes() if isinstance(value,Path) else value
                    item=tarfile.TarInfo(key);item.size=len(data);item.mode=0o644
                    tar.addfile(item,io.BytesIO(data));table[key]=dict(bytes=len(data),sha256=digest(data))
    dump(name+'-files.json',table);print('archived',name,len(files),flush=True)
def terminal(pid):
    p=Path('/proc')/str(pid)/'stat'
    return not p.exists() or p.read_text().split()[2]=='Z'
root=Path(tempfile.mkdtemp(prefix='uos-history-inputs-',dir=SP.parent))
shutil.copytree(candidate,root,dirs_exist_ok=True,ignore=lambda p,n:['validation'] if Path(p).name=='docs' else ['__pycache__'] if '__pycache__' in n else [])
inputs=manifest(root);runtime={p:h for p,h in inputs.items() if not p.startswith(('docs/','tests/')) and not p.endswith('.md')}
executions={};statuses={};jobfiles={};outputs={};blobs={};cases=0;cpu_jobs=0;vice_jobs=0
processes=subprocess.check_output(['ps','-eo','pid,ppid,stat,args'],text=True)
for generation,run in enumerate(s['qualification_runs']):
    folder=Path(run['jobs']);execution_root=Path(run['root'])
    manifest_path=folder/'inputs.json'
    if not manifest_path.exists():manifest_path=Path(str(execution_root)+'-inputs.json')
    initial=json.loads(manifest_path.read_text());assert manifest(execution_root)==initial
    assert all(initial.get(p)==h for p,h in runtime.items()),str(execution_root)
    labels=run.get('labels') or [json.loads(p.read_text())['label'] for p in sorted(folder.glob('*.status.json'))]
    ordinary=[]
    for p,h in initial.items():
        if inputs.get(p)!=h:blobs[h]=execution_root/p
    for name in labels:
        status=json.loads((folder/(name+'.status.json')).read_text());log=folder/(name+'.log')
        assert status['exit_code']==0 and terminal(status['pid']) and status['cwd']==str(execution_root),name
        assert name not in statuses;statuses[name]=status
        jobfiles[name+'.status.json']=folder/(name+'.status.json');jobfiles[name+'.log']=log
        if name.startswith('vice'):
            result=Path(log.read_text().split('Native pointer VICE: ')[1].splitlines()[0]);report=json.loads((result/'report.json').read_text())
            assert report['passed'] and report['all_host_processes_terminal'] and report['physical_hardware_io'] is False
            assert report['xvfb_terminal'] and terminal(report['private_x_pid'])
            assert not any(str(result) in line for line in processes.splitlines())
            assert not any('Xvfb '+report['private_x_display']+' ' in line for line in processes.splitlines())
            outputs.update({name+'/'+p.relative_to(result).as_posix():p for p in result.rglob('*') if p.is_file()})
            executions[name]=dict(root=str(execution_root),inputs=initial,jobs=[name]);vice_jobs+=1
            if name=='vice64':shutil.copyfile(result/'editor-history-mouse-redo.png',out/'editor-history.png')
        else:
            report=json.loads((folder/(name+'.json')).read_text());assert report['passed'],name
            assert report['physical_hardware_io'] is False,name
            cases+=len(report.get('cases',report.get('documents',[])))
            cpu_jobs+=1;ordinary.append(name);jobfiles[name+'.report.json']=folder/(name+'.json')
            if name in ('oracle','oracle-legacy'):
                fixture=Path(report['work']);outputs.update({'cpu-oracles/'+name+'/'+p.name:p for p in fixture.iterdir() if p.is_file()})
    if ordinary:executions[f'cpu-{generation+1}']=dict(root=str(execution_root),inputs=initial,jobs=ordinary)
assert vice_jobs==2 and cpu_jobs==45,(vice_jobs,cpu_jobs)
build=json.loads(Path(s['rebuild_report']).read_text());assert build['passed'] and len(build['images'])==35
rebuilt=Path(s['rebuild_root'])
assert all(v['candidate']==v['rebuild']==inputs[p]==digest((rebuilt/p).read_bytes()) for p,v in build['images'].items())
jobfiles['build.json']=Path(s['rebuild_report']);jobfiles['build.log']=Path(s['rebuild_log'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==s['parent']
subprocess.run(['git','diff','--quiet','HEAD','--'],cwd=repo,check=True)
assert all(digest((repo/p).read_bytes())==h for p,h in s['protected'].items())
assert digest((repo/'docs/validation/2026-09-14-native-shared-clipboard/SHA256SUMS').read_bytes())==s['parent_seal']
subprocess.run(['git','verify-commit',s['parent']],cwd=repo,check=True,capture_output=True)
tracked=set(subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0'))
new={p for p in inputs if p not in s['inputs'] and not p.startswith('target/')}
changes={}
for p in sorted((tracked|new)&set(inputs)):
    old=digest((repo/p).read_bytes()) if (repo/p).exists() else None
    if old!=inputs[p]:changes[p]=dict(before=old,after=inputs[p])
assert set(changes).isdisjoint(s['protected'])
dump('changes.json',changes);dump('executions.json',executions);dump('jobs.json',statuses)
archive('inputs',{p:root/p for p in inputs});archive('execution-blobs',blobs);archive('jobs',jobfiles);archive('outputs',outputs)
archive('rebuilt-images',{p:rebuilt/p for p in build['images']})
archive('parent-images',{p:repo/p for p in build['images'] if (repo/p).exists()})
archive('parent-changes',{p:repo/p for p,v in changes.items() if v['before'] is not None})
development={p.name:p for p in SP.parent.glob('uos-history-*') if p.is_file() and p.suffix in ('.json','.log','.py')}
development['state-before-archive.json']=SP
for folder in SP.parent.glob('uos-history-dev*-jobs'):
    development.update({folder.name+'/'+p.name:p for p in folder.iterdir() if p.is_file()})
for run in s['qualification_runs']:
    folder=Path(run['jobs'])
    if 'labels' not in run:continue
    for p in folder.glob('*.status.json'):
        label=json.loads(p.read_text())['label']
        if label in run['labels']:continue
        for suffix in ('status.json','json','log'):
            f=folder/(label+'.'+suffix)
            if f.exists():development['excluded-'+folder.name+'/'+f.name]=f
for run in s.get('superseded_runs',[]):
    folder=Path(run['jobs']);execution_root=Path(run['root'])
    development.update({'superseded-'+folder.name+'/'+p.name:p for p in folder.iterdir() if p.is_file()})
    development['superseded-'+folder.name+'/ci_native_clipboard_apps.py']=execution_root/'tests/ci_native_clipboard_apps.py'
    development['superseded-'+folder.name+'/ci_native_pointer_iec.py']=execution_root/'tests/ci_native_pointer_iec.py'
    development['superseded-'+folder.name+'/vice_keyboard.py']=execution_root/'tests/vice_keyboard.py'
for run in s['qualification_runs']+s.get('superseded_runs',[]):
    folder=Path(run['jobs'])
    for p in folder.glob('vice*.status.json'):
        status=json.loads(p.read_text())
        if not status.get('exit_code'):continue
        log=folder/(status['label']+'.log')
        if 'Native pointer VICE: ' not in log.read_text():continue
        result=Path(log.read_text().split('Native pointer VICE: ')[1].splitlines()[0])
        for name in ('run.py','report.json','failure.png','failure-editor-ram.bin','failure-editor-workspace.bin','unexpected-key-input.bin','vice.log'):
            source=result/name
            if source.exists():development['failed-'+result.name+'/'+name]=source
        for source in result.glob('queue-write-*.bin'):
            development['failed-'+result.name+'/'+source.name]=source
development_runtime={}
for specpath in sorted(SP.parent.glob('uos-history-dev*-spec.json')):
    spec=json.loads(specpath.read_text());execution_root=Path(spec['root'])
    observed=manifest(execution_root)
    development['development-inputs/'+execution_root.name+'.json']=(json.dumps(dict(
        manifest=observed,observed_after_execution=True),indent=2,sort_keys=True)+'\n').encode()
    changed={p:h for p,h in observed.items() if inputs.get(p)!=h}
    development_runtime[str(execution_root)]=changed
    for p,h in changed.items():development['development-versions/'+h]=execution_root/p
for run in s.get('superseded_runs',[]):
    execution_root=Path(run['root']);initial=json.loads((Path(run['jobs'])/'inputs.json').read_text())
    assert manifest(execution_root)==initial
    changed={p:h for p,h in initial.items() if inputs.get(p)!=h}
    development_runtime[str(execution_root)]=changed
    for p,h in changed.items():development['development-versions/'+h]=execution_root/p
development['development-versions.json']=(json.dumps(development_runtime,indent=2,sort_keys=True)+'\n').encode()
archive('development',development)
rom=Path('/usr/share/vice/C128/kernal-318020-05.bin')
dump('provenance.json',dict(base=s['parent'],previous_seal=s['parent_seal'],physical_hardware_io=False,
    base_signature='G phoenix-agent@2acrestudios.com',processes_terminal_at_archival=True,
    inputs=inputs,runtime_inputs=runtime,runtime_identity=digest(json.dumps(runtime,sort_keys=True).encode()),
    cpu_jobs=cpu_jobs,cpu_cases=cases,cpu_case_groups=cases-5,legacy_document_states=5,vice_jobs=vice_jobs,independent_builds=1,
    execution_storage='Final input bytes are reused by path/hash. Other execution inputs are stored by SHA256.',
    kernal_rom=dict(name=rom.name,sha256=digest(rom.read_bytes()),redistributed=False),
    tools={name:subprocess.run(cmd,text=True,capture_output=True,check=True).stdout.splitlines()[0] for name,cmd in {
        'cc':['cc','--version'],'64tass':['64tass','--version'],'x128':['x128','--version'],
        'python':['python3','--version'],'cpu-python':['/home/marc/.venvs/uos-tests/bin/python3','--version']}.items()}))
shutil.copyfile(SP.parent/'uos-history-verify.py',out/'verify.py')
s.update(frozen=str(root),record=str(out),apply_input_paths=sorted(changes),cpu_cases=cases,stage='Qualification archived; offline audit and seal pending')
SP.write_text(json.dumps(s,indent=2)+'\n')
print(json.dumps(dict(record=str(out),changes=len(changes),inputs=len(inputs),cases=cases),indent=2))
