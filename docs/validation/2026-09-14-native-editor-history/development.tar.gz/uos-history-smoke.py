import sys,json,traceback
from pathlib import Path
root=Path('/var/tmp/arc-scratch/uos-editor-history-fre7fz85');sys.path[:0]=[str(root/'tests'),str(root)]
from ci_native_editor_gui import GraphicalEditor
from ci_native_reu_calc import component
result=dict(passed=False,physical_hardware_io=False)
try:
 e=GraphicalEditor(device=9)
 print('ready',e.value('eh_available'),e.m.stats(),flush=True)
 e.type('ABC');e.check(b'ABC',3,True)
 print('typed',component(e,'bh_count'),e.value('eh_warning'),flush=True)
 e.key(26);e.check(b'AB',2,True,status=27)
 e.key(26);e.check(b'A',1,True,status=27)
 e.key(26);e.check(b'',0,False,status=27)
 e.key(26);e.check(b'',0,False,status=31)
 e.key(25);e.check(b'A',1,True,status=28)
 e.prompt(0x86,'SAVED');e.check(b'A',1,False,status=1,name='SAVED')
 e.key(25);e.check(b'AB',2,True,status=28)
 e.key(26);e.check(b'A',1,False,status=27)
 e.type('!');e.check(b'A!',2,True)
 e.key(25);e.check(b'A!',2,True,status=31)
 e.key(26);e.check(b'A',1,False,status=27)
 e.exit();e.restored()
 result.update(passed=True,instructions=e.instructions,checked=e.checked)
 print('PASS',result,flush=True)
except BaseException:
 result['error']=traceback.format_exc();raise
finally:Path('/var/tmp/arc-scratch/uos-history-smoke.json').write_text(json.dumps(result,indent=2)+'\n')
