import hashlib,json,shutil,subprocess
from pathlib import Path
sp=Path('/var/tmp/arc-scratch/uos-editor-history-current.json');s=json.loads(sp.read_text())
repo=Path(s['repo']);record=Path(s['record']);frozen=Path(s['frozen']);digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args,**kw):return subprocess.run(['git',*args],cwd=repo,check=True,text=True,capture_output=True,**kw)
assert not s['applied'] and git('rev-parse','HEAD').stdout.strip()==s['parent']
git('diff','--quiet','HEAD','--');git('verify-commit',s['parent'])
assert all(digest(repo/p)==h for p,h in s['protected'].items())
assert digest(repo/'docs/validation/2026-09-14-native-shared-clipboard/SHA256SUMS')==s['parent_seal']
checks=json.loads((record/'audit.json').read_text());assert checks['passed'] and checks['jobs']==47 and checks['complete_reu_document_snapshots']==13
seals={line.split('  ',1)[1]:line.split('  ',1)[0] for line in (record/'SHA256SUMS').read_text().splitlines()}
assert set(seals)=={p.name for p in record.iterdir() if p.is_file() and p.name!='SHA256SUMS'}
assert all(digest(record/p)==h for p,h in seals.items())
changes=json.loads((record/'changes.json').read_text());assert set(changes).isdisjoint(s['protected'])
for p,change in changes.items():
 assert '..' not in Path(p).parts and not Path(p).is_absolute() and not p.startswith('docs/validation/')
 assert digest(frozen/p)==change['after']
 assert (digest(repo/p) if (repo/p).exists() else None)==change['before']
dest=repo/'docs/validation'/record.name;assert not dest.exists()
for p in changes:
 (repo/p).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(frozen/p,repo/p)
shutil.copytree(record,dest)
assert all(digest(repo/p)==v['after'] for p,v in changes.items())
assert all(digest(repo/p)==h for p,h in s['protected'].items())
s.update(applied=True,record_in_repo=str(dest),stage='Applied qualified history; signed local commit pending')
sp.write_text(json.dumps(s,indent=2)+'\n')
print(json.dumps(dict(applied=True,changed_files=len(changes),record=str(dest),seal=digest(dest/'SHA256SUMS')),indent=2))
