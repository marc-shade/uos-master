import json
from pathlib import Path
sp=Path('/var/tmp/arc-scratch/uos-editor-history-current.json');s=json.loads(sp.read_text())
p=sp.parent/'uos-history-watch.json';old=json.loads(p.read_text()) if p.exists() else {}
now={};done=0;queued=0
for run in s['qualification_runs']:
 jobs=Path(run['jobs']);names=run.get('labels') or [p.name[:-12] for p in jobs.glob('*.status.json')]
 for name in names:
  f=jobs/(name+'.status.json')
  if not f.exists():queued+=1;continue
  status=json.loads(f.read_text());lines=(jobs/(name+'.log')).read_text().splitlines()
  state='PASS' if status.get('exit_code')==0 else 'FAIL' if 'exit_code' in status else 'RUNNING'
  now[name]=dict(state=state,last=lines[-1] if lines else '')
  if state=='PASS':done+=1
  if old.get(name)!=now[name]:print(name,state,now[name]['last'][-190:])
p.write_text(json.dumps(now,indent=2)+'\n');print('Completed',done,'queued',queued)
