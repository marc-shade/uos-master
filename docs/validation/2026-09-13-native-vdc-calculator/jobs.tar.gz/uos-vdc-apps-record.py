import gzip,hashlib,io,json,shutil,sys,tarfile,tempfile
from pathlib import Path
STATE=Path('/var/tmp/arc-scratch/uos-vdc-apps-current.json')
s=json.loads(STATE.read_text());candidate=Path(s['candidate']);record=Path(s['record'])
sha=lambda b:hashlib.sha256(b).hexdigest()
def dump(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
def archive(label,files):
 assert not (record/'SHA256SUMS').exists(),'sealed record is immutable'
 manifest={}
 with (record/(label+'.tar.gz')).open('wb') as raw:
  with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
   with tarfile.open(fileobj=gz,mode='w') as tar:
    for name,p in sorted(files.items()):
     p=Path(p);assert p.is_file() and not p.is_symlink();data=p.read_bytes()
     entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o644;tar.addfile(entry,io.BytesIO(data))
     manifest[name]=dict(bytes=len(data),sha256=sha(data))
 dump(record/(label+'-files.json'),manifest)
 archives=json.loads((record/'archives.json').read_text()) if (record/'archives.json').exists() else {}
 archives[label]=dict(archive=label+'.tar.gz',manifest=label+'-files.json',sha256=sha((record/(label+'.tar.gz')).read_bytes()),payload_files=len(manifest))
 dump(record/'archives.json',archives)
 return manifest
if __name__=='__main__':
 assert sys.argv[1]=='freeze' and not (record/'inputs.tar.gz').exists()
 paths=s['frozen_input_paths'];frozen=Path(s['frozen'])
 assert all((frozen/p).read_bytes()==(candidate/p).read_bytes() for p in paths)
 archive('inputs',{p:frozen/p for p in paths})
 images={p:sha((frozen/p).read_bytes()) for p in paths if p.startswith(('target/native/','target/native-desktop/')) and Path(p).suffix in ('.prg','.d64','.d81')}
 assert len(images)==33;dump(record/'images.json',images)
 (record/'base-commit.txt').write_text(s['base']+'\n')
 prior=Path('/home/marc/geos128/uos/docs/validation/2026-09-13-native-d81-suite')
 shutil.copyfile(prior/'images.json',record/'base-images.json')
 refs=Path('/var/tmp/arc-scratch/uos-vdc-reference')
 archive('reference',{**{p.name:p for p in refs.iterdir() if p.name in ('vdc-draw.c','vdc-mem.c','provenance.json')},
   'vdc_deft.vpl':Path('/usr/share/vice/C128/vdc_deft.vpl'),
   'editor-declare.src':Path('/home/marc/code/cbmsrc/EDITOR_C128/declare.src'),
   'editor-sysdoc.src':Path('/home/marc/code/cbmsrc/EDITOR_C128/sysdoc.src')})
 builds=[]
 for i in (1,2):
  target=Path(tempfile.mkdtemp(prefix=f'uos-vdc-calc-build{i}-',dir='/var/tmp/arc-scratch'))
  for path in paths:
   if path.startswith('target/'):continue
   dest=target/path;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(frozen/path,dest)
  builds.append(str(target))
 s['rebuild_sources']=builds;dump(STATE,s)
 print(json.dumps(dict(record=str(record),inputs=len(paths),images=len(images),rebuild_sources=builds)))
