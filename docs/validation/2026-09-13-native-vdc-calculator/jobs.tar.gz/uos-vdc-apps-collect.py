import hashlib,importlib.util,json,re,subprocess
from pathlib import Path
spec=importlib.util.spec_from_file_location('record','/var/tmp/arc-scratch/uos-vdc-apps-record.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
scratch=Path('/var/tmp/arc-scratch');root=m.candidate;record=m.record
assert not (record/'SHA256SUMS').exists()
labels=['boot-pack1','calc-core1','calc-fault2','setup-final','desktop-final','calc-gui-final','media-final','vice81-final','vice64-final','rebuild-1','rebuild-2']
for label in labels:
 p=scratch/('uos-vdc-apps-'+label+'.status.json')
 if not p.exists() or not json.loads(p.read_text())['terminal']:raise SystemExit('Still pending: '+label)
 assert json.loads(p.read_text())['passed'],label
versions={};jobs={};files={}
for label in labels:
 prefix=scratch/('uos-vdc-apps-'+label)
 cfg=json.loads(prefix.with_suffix('.config.json').read_text());status=json.loads(prefix.with_suffix('.status.json').read_text())
 overlay={};tested=Path(cfg['cwd'])
 for name,digest in cfg['source_sha256'].items():
  if Path(name).suffix not in ('.py','.asm','.inc','.c','.s','.cfg','.prg','.d64','.d81'):continue
  if m.sha((root/name).read_bytes())==digest:continue
  p=tested/name;assert p.is_file() and m.sha(p.read_bytes())==digest,(label,name)
  key=digest+'/'+Path(name).name;versions[key]=p;overlay[name]=key
 jobs[label]=dict(status=status,config=cfg,source_overlay=overlay)
 for suffix in ('.config.json','.status.json','.log'):files[label+suffix]=prefix.with_suffix(suffix)
for name in ('uos-vdc-apps-job.py','uos-vdc-apps-record.py','uos-vdc-apps-collect.py'):files[name]=scratch/name
m.archive('jobs',files);m.archive('source-versions',versions);m.dump(record/'jobs.json',jobs)
reports=[label+'.json' for label in labels if label not in ('vice81-final','vice64-final','rebuild-1','rebuild-2')]
m.archive('cpu',{name:scratch/('uos-vdc-apps-'+name) for name in reports});m.dump(record/'cpu-reports.json',reports)
for label,job in [('vice81','vice81-final'),('vice64','vice64-final')]:
 log=(scratch/('uos-vdc-apps-'+job+'.log')).read_text();folder=Path(re.search(r'Native pointer VICE: (.+)',log)[1])
 assert json.loads((folder/'report.json').read_text())['passed']
 m.archive(label,{p.relative_to(folder).as_posix():p for p in folder.rglob('*') if p.is_file() and '__pycache__' not in p.parts})
preliminary={}
for label in ('calc-core-dev','calc-fault-dev','calc-core-dev2','calc-fault-dev2','boot-pack-dev','vice-calc-dev','calc-fault1','vice-calc1'):
 for suffix in ('.config.json','.status.json','.log','.json'):
  p=scratch/('uos-vdc-apps-'+label+suffix)
  if p.is_file():preliminary[label+suffix]=p
 if label.startswith('vice'):
  log=(scratch/('uos-vdc-apps-'+label+'.log')).read_text();folder=Path(re.search(r'Native pointer VICE: (.+)',log)[1])
  preliminary.update({label+'/'+p.relative_to(folder).as_posix():p for p in folder.rglob('*') if p.is_file() and '__pycache__' not in p.parts})
observed=scratch/'uos-vdc-apps-supervision.json'
if observed.exists():preliminary[observed.name]=observed
m.archive('preliminary',preliminary)
print('Collected',len(jobs),'successful supervised jobs and',len(reports),'CPU/media reports')
