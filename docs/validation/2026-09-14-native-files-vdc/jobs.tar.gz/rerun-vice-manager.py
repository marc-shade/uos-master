import json,pathlib,subprocess,sys
root,q=map(pathlib.Path,sys.argv[1:]);commands=json.loads((q/'rerun-vice-commands.json').read_text());results=[]
for name,command in commands.items():
 results.append(subprocess.run(['/usr/bin/python3','-B',str(q/'supervise.py'),str(root),str(q),name,*command]).returncode)
(q/'rerun-vice-manager.json').write_text(json.dumps(dict(terminal=True,supervisors_returned=results))+'\n')
