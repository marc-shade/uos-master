#!/usr/bin/env python3
"""Measure CPU cycles to original app entry; stubbed IEC is not disk timing."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--report', type=Path, required=True)
args = parser.parse_args()
root = args.root.resolve()
sys.path[:0] = [str(root/'tests'), str(root)]
from py65.devices.mpu6502 import MPU
from ci_native_heap import Machine
from ci_native_apps import RUN
from ci_native_files import StreamIEC
from native_app_pack import decode
from native_image import validate

report = dict(passed=False, physical_hardware_io=False, cases=[],
              notes='CPU model cycles; IEC calls are stubbed. These are not disk-load or physical elapsed-time measurements.')
try:
    for name in ('desktop', 'paint'):
        packed = (root/'target/native-desktop'/f'{name}.prg').read_bytes()
        raw = decode(packed)
        for kind, image in (('raw', raw), ('packed', packed)):
            m = Machine()
            io = StreamIEC(m, {(8, b'TIMING', b'P'): image})
            ram = m.ram
            ram[0x3d21:0x3d23] = bytes([8, 6])
            ram[0x3d40:0x3d46] = b'TIMING'
            cpu = MPU(memory=m.bus, pc=RUN)
            cpu.sp = 0xe0
            cpu.p = 0x20
            cpu.stPushWord(0xaff)
            outer_entry = validate(image)['entry']
            raw_entry = validate(raw)['entry']
            at_wrapper = None
            for step in range(16000000):
                if cpu.pc == outer_entry and at_wrapper is None:
                    at_wrapper = cpu.processorCycles
                if cpu.pc == raw_entry and at_wrapper is not None:
                    assert bytes(ram[0x6020:0x6000+len(raw)-2]) == raw[34:]
                    assert not io.handles
                    break
                assert not (cpu.pc == 0xb00 and cpu.sp == 0xe0), 'exited before program entry'
                if not io.stub(cpu):
                    cpu.step()
            else:
                raise AssertionError('startup did not complete')
            result = dict(app=name, kind=kind, file_bytes=len(image),
                          sha256=hashlib.sha256(image).hexdigest(),
                          loader_cpu_cycles=at_wrapper,
                          startup_cpu_cycles=cpu.processorCycles-at_wrapper,
                          total_cpu_cycles=cpu.processorCycles)
            report['cases'].append(result)
            print(json.dumps(result), flush=True)
    report['passed'] = True
finally:
    args.report.write_text(json.dumps(report, indent=2)+'\n')
