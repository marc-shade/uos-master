import hashlib,json,shutil,tempfile
from pathlib import Path
sp=Path('/var/tmp/arc-scratch/uos-shared-clipboard-current.json');s=json.loads(sp.read_text());candidate=Path(s['candidate']);root=Path(tempfile.mkdtemp(prefix='uos-clipboard-q16-',dir=sp.parent))
shutil.copytree(candidate,root,dirs_exist_ok=True,ignore=lambda p,n:['validation'] if Path(p).name=='docs' else ['__pycache__'] if '__pycache__' in n else [])
manifest={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
jobs=Path(str(root)+'-vice-jobs');jobs.mkdir();(jobs/'inputs.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
spec=dict(root=str(root),jobs=str(jobs),workers=1,tests=[dict(label='vice16',args=['tests/ci_native_pointer_iec.py','--editor-only','--editor-selection','--editor-clipboard'],report=False)])
(sp.parent/'uos-clipboard-q16-vice-spec.json').write_text(json.dumps(spec,indent=2)+'\n')
s['qualification_runs'][1]['labels']=['vice64'];s['qualification_runs'].append(dict(root=str(root),jobs=str(jobs)));s['stage']='Final runtime dev10 passes clipboard workflows; physical-bank progress reads corrected after a false counter during launcher loading'
sp.write_text(json.dumps(s,indent=2,sort_keys=True)+'\n');print(root)
