import hashlib,json,shutil,tempfile
from pathlib import Path
sp=Path('/var/tmp/arc-scratch/uos-shared-clipboard-current.json');s=json.loads(sp.read_text());candidate=Path(s['candidate'])
root=Path(tempfile.mkdtemp(prefix='uos-clipboard-q15-',dir=sp.parent))
shutil.copytree(candidate,root,dirs_exist_ok=True,ignore=lambda p,n:['validation'] if Path(p).name=='docs' else ['__pycache__'] if '__pycache__' in n else [])
manifest={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
runs=[]
for kind in ('cpu','vice'):
 spec=json.loads((sp.parent/('uos-clipboard-q8-cpu-spec.json' if kind=='cpu' else 'uos-clipboard-q9-vice-spec.json')).read_text());jobs=Path(str(root)+'-'+kind+'-jobs');jobs.mkdir()
 spec.update(root=str(root),jobs=str(jobs),workers=4 if kind=='cpu' else 2)
 if kind=='cpu':
  spec['tests']+= [dict(label='keyboard-matrix',args=['tests/ci_native_keyboard_matrix.py']),dict(label='keyboard-resident',args=['tests/ci_native_keyboard.py']),dict(label='claude-input',args=['tests/ci_native_claude_gui.py','--case','input'])]
 (jobs/'inputs.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
 (sp.parent/('uos-clipboard-q15-'+kind+'-spec.json')).write_text(json.dumps(spec,indent=2)+'\n')
 runs.append(dict(root=str(root),jobs=str(jobs)))
s['superseded_runs']+=s['qualification_runs'];s['qualification_runs']=runs
s['superseded_builds'].append(dict(root=s['rebuild_root'],log=s['rebuild_log'],report=s['rebuild_report']))
rebuild=Path(tempfile.mkdtemp(prefix='uos-clipboard-rebuild-dev10-',dir=sp.parent));shutil.copytree(root,rebuild,dirs_exist_ok=True)
for name in ('native','native-desktop'):shutil.rmtree(rebuild/'target'/name)
s.update(latest_build='dev10',stage='Nested ROM key-scan reproduction and all-key matrix filter implemented; final CPU and VICE qualification running',final_root=str(root),rebuild_root=str(rebuild),rebuild_log=str(sp.parent/'uos-clipboard-rebuild-dev10.log'),rebuild_report=str(sp.parent/'uos-clipboard-rebuild-dev10.json'))
sp.write_text(json.dumps(s,indent=2,sort_keys=True)+'\n');print(root)
