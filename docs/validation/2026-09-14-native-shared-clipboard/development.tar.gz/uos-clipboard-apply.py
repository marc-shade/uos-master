import hashlib
import json
from pathlib import Path
import shutil
import subprocess

state_path = Path('/var/tmp/arc-scratch/uos-shared-clipboard-current.json')
state = json.loads(state_path.read_text())
repo = Path('/home/marc/geos128/uos')
record = Path(state['record'])
source = Path(state['frozen'])
relative_record = record.relative_to(Path(state['candidate']))
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert (record/'SHA256SUMS').is_file()
assert digest(record/'SHA256SUMS') == state['seal']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == state['base']
subprocess.run(['git', 'diff', '--quiet', 'HEAD', '--'], cwd=repo, check=True)
for name, expected in state['protected'].items():
    assert digest(repo/name) == expected, name
untracked = set(subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=repo).decode().split('\0'))-{''}
assert untracked == set(state['protected'])
changes = json.loads((record/'changes.json').read_text())
assert sorted(changes) == state['apply_input_paths']
assert not (repo/relative_record).exists()
for name, hashes in changes.items():
    path = repo/name
    assert (digest(path) if path.exists() else None) == hashes['before'], name
    assert digest(source/name) == hashes['after'], name
for line in (record/'SHA256SUMS').read_text().splitlines():
    expected, name = line.split('  ', 1)
    assert digest(record/name) == expected, name
for name in changes:
    path = repo/name
    path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source/name, path)
shutil.copytree(record, repo/relative_record)
for name, hashes in changes.items():
    assert digest(repo/name) == hashes['after'], name
for name, expected in state['protected'].items():
    assert digest(repo/name) == expected, name
state.update(applied=True,applied_record=str(repo/relative_record), stage='sealed shared clipboard integration applied for signed local commit')
state_path.write_text(json.dumps(state, indent=2)+'\n')
print(json.dumps(dict(applied_inputs=len(changes), record=str(repo/relative_record)), indent=2))
