import hashlib,json,shutil,tempfile
from pathlib import Path
sp=Path('/var/tmp/arc-scratch/uos-shared-clipboard-current.json');s=json.loads(sp.read_text());candidate=Path(s['candidate'])
root=Path(tempfile.mkdtemp(prefix='uos-clipboard-q12-',dir='/var/tmp/arc-scratch'))
shutil.copytree(candidate,root,dirs_exist_ok=True,ignore=lambda p,n:['validation'] if Path(p).name=='docs' else ['__pycache__'] if '__pycache__' in n else [])
p=root/'tests/ci_native_pointer_iec.py';t=p.read_text()
t=t.replace("        def key(name,target,after_key=None):", "        queue_trace=[]\n        queue_watch=[]\n        def key(name,target,after_key=None):")
old="                    after=int.from_bytes(read(0x3d13,2),'little')\n                    if after not in"
new="""                    after=int.from_bytes(read(0x3d13,2),'little')
                    if queue_watch:
                        error,regs=mon._recv(mon._send(0x31,b'\\0'));assert not error
                        raw=bytes(mon.read_mem(0xcc,0xd5,bank=banks['ram00']))
                        kd=bytes(mon.read_mem(0x34a,0x353,bank=banks['ram00']))
                        io=bytes(mon.read_mem(0xdc00,0xdc03,bank=banks['io']))
                        row=dict(key=name,after=after,registers=regs.hex(),zp=raw.hex(),queue=kd.hex(),cia=io.hex())
                        if not queue_trace or queue_trace[-1]!=row:
                            queue_trace.append(row)
                            report['queue_trace']=queue_trace;save()
                    if after not in"""
assert old in t;t=t.replace(old,new)
old="                            report.setdefault('clipboard_key_checkpoints',[]).append(dict(key=letter,address=entry,before=before,after=count))"
new=old+"""
                            if letter in ('c','x'):
                                error,watch=mon._recv(mon._send(0x12,(0x34a).to_bytes(2,'little')+(0x353).to_bytes(2,'little')+bytes([1,1,2,0,0])))
                                assert not error
                                queue_watch.append(watch[:4])"""
assert old in t;t=t.replace(old,new)
old="                            error,_=mon._recv(mon._send(0x13,checkpoint_id));mon.resume()"
new="""                            for watch_id in queue_watch:
                                error,_=mon._recv(mon._send(0x13,watch_id));assert not error
                            queue_watch.clear()
"""+old
assert old in t;t=t.replace(old,new)
p.write_text(t)
jobs=Path(str(root)+'-vice-jobs');jobs.mkdir()
manifest={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
(jobs/'inputs.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
spec=dict(root=str(root),jobs=str(jobs),workers=1,tests=[dict(label='vice16',args=['tests/ci_native_pointer_iec.py','--editor-only','--editor-selection','--editor-clipboard'],report=False)])
Path('/var/tmp/arc-scratch/uos-clipboard-q12-vice-spec.json').write_text(json.dumps(spec,indent=2)+'\n')
s['superseded_runs'].append(s['qualification_runs'].pop());s['qualification_runs'].append(dict(root=str(root),jobs=str(jobs)))
sp.write_text(json.dumps(s,indent=2,sort_keys=True)+'\n')
print(root)
