import sys,json
from pathlib import Path
sys.path[:0]=[sys.argv[1]+'/tests',sys.argv[1]]
import ci_native_keyboard as k
from py65.devices.mpu6502 import MPU
rows=[]
for at in range(0,88,8):
 b=k.machine();b.config=0;b.pressed={58};events=[];nested=[False]
 cpu=MPU(memory=b,pc=0xff9f);cpu.sp=0xc0;cpu.stPushWord(0xb7f)
 for step in range(30000):
  if cpu.pc==0xb80:break
  if cpu.pc==0xc59d and cpu.y==at and not nested[0]:
   nested[0]=True
   inner=MPU(memory=b,pc=0xff9f);inner.sp=0x60;inner.stPushWord(0xb7f)
   for _ in range(30000):
    if inner.pc==0xb80:break
    inner.step()
   else:raise Exception('inner')
  if cpu.pc==0xc6ad:events.append(dict(a=cpu.a,x=cpu.x,y=cpu.y,cia=dict(b.ports)))
  cpu.step()
 else:raise Exception('outer')
 b.config=14;key=k.invoke(b,0x1c3b).a
 rows.append(dict(at=at,key=key,events=events))
print(json.dumps(rows,indent=2))
