import concurrent.futures,json,os,subprocess,sys,time
from pathlib import Path
spec=json.loads(Path(sys.argv[1]).read_text());root=Path(spec['root']);jobs=Path(spec['jobs']);jobs.mkdir(exist_ok=True)
def run(item):
    label=item['label'];command=[item.get('python','/home/marc/.venvs/uos-tests/bin/python3'),'-B',*item['args']]
    if item.get('report',True):command.extend(['--report',str(jobs/(label+'.json'))])
    env=os.environ.copy();env.update(item.get('env',{}));started=time.time()
    with (jobs/(label+'.log')).open('wb') as out:
        p=subprocess.Popen(command,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
        status=dict(label=label,pid=p.pid,cwd=str(root),command=command,environment=item.get('env',{}),started=started)
        (jobs/(label+'.status.json')).write_text(json.dumps(status,indent=2)+'\n')
        code=p.wait()
    status.update(exit_code=code,finished=time.time())
    (jobs/(label+'.status.json')).write_text(json.dumps(status,indent=2)+'\n')
    print(label,code,flush=True)
    return status
with concurrent.futures.ThreadPoolExecutor(max_workers=spec.get('workers',3)) as pool:results=list(pool.map(run,spec['tests']))
(jobs/'complete.json').write_text(json.dumps(results,indent=2)+'\n')
sys.exit(int(any(r['exit_code'] for r in results)))
