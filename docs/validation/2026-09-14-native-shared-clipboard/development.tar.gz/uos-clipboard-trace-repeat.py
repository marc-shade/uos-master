import hashlib,json,shutil,tempfile
from pathlib import Path
sp=Path('/var/tmp/arc-scratch/uos-shared-clipboard-current.json');s=json.loads(sp.read_text());source=Path(json.loads(Path('/var/tmp/arc-scratch/uos-clipboard-q13-vice-spec.json').read_text())['root'])
root=Path(tempfile.mkdtemp(prefix='uos-clipboard-q14-',dir=sp.parent));shutil.copytree(source,root,dirs_exist_ok=True)
p=root/'tests/ci_native_pointer_iec.py';t=p.read_text();old="                    editor_control('c')\n                    editor_view('editor-clipboard-copy'"
new="                    for attempt in range(16):\n                        print('TRACE: Copy attempt',attempt,flush=True)\n                        editor_control('c')\n                    editor_view('editor-clipboard-copy'"
assert old in t;p.write_text(t.replace(old,new))
jobs=Path(str(root)+'-vice-jobs');jobs.mkdir()
manifest={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
(jobs/'inputs.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
spec=dict(root=str(root),jobs=str(jobs),workers=1,tests=[dict(label='vice16',args=['tests/ci_native_pointer_iec.py','--editor-only','--editor-selection','--editor-clipboard'],report=False)])
Path('/var/tmp/arc-scratch/uos-clipboard-q14-vice-spec.json').write_text(json.dumps(spec,indent=2)+'\n')
s['superseded_runs'].append(dict(root=str(root),jobs=str(jobs)));sp.write_text(json.dumps(s,indent=2,sort_keys=True)+'\n');print(root)
