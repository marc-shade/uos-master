import json,subprocess,sys
from pathlib import Path
root=Path('/var/tmp/arc-scratch/uos-native-d81-suite-12pp4vi1')
results=[]
for driver,args in [('heap',[]),('relocation',[]),('modules',[]),('module_editor',[]),('running_layout',[]),('running_layout',['--desktop-boot'])]:
 name=driver+('-desktop' if args else '')
 report=Path('/var/tmp/arc-scratch/uos-d81-regress-'+name+'.json')
 command=[sys.executable,'-B','tests/ci_native_'+driver+'.py',*args,'--report',str(report)]
 print('RUN',name,flush=True)
 result=subprocess.run(command,cwd=root)
 results.append(dict(driver=driver,command=command,exit_code=result.returncode,report=str(report)))
 Path('/var/tmp/arc-scratch/uos-d81-regress-results.json').write_text(json.dumps(results,indent=2)+'\n')
 if result.returncode:sys.exit(result.returncode)
