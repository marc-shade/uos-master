import hashlib,json,subprocess,sys,time
from pathlib import Path
label=sys.argv[1];command=sys.argv[2:]
state=Path('/var/tmp/arc-scratch/uos-d81-suite-current.json')
s=json.loads(state.read_text());root=Path(s['candidate']);prefix=Path('/var/tmp/arc-scratch/uos-d81-'+label)
paths=set(s['input_paths']+s['new_source_paths'])
config=dict(command=command,cwd=str(root),source_sha256={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(paths) if (root/p).is_file()})
prefix.with_suffix('.config.json').write_text(json.dumps(config,indent=2)+'\n')
status=dict(terminal=False,passed=False,started=time.time(),command=command)
prefix.with_suffix('.status.json').write_text(json.dumps(status,indent=2)+'\n')
with prefix.with_suffix('.log').open('wb') as output:
 result=subprocess.run(command,cwd=root,stdout=output,stderr=subprocess.STDOUT)
status.update(terminal=True,passed=result.returncode==0,exit_code=result.returncode,finished=time.time())
prefix.with_suffix('.status.json').write_text(json.dumps(status,indent=2)+'\n')
print(json.dumps(status),flush=True)
sys.exit(result.returncode)
