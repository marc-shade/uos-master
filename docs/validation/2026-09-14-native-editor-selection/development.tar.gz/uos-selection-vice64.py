import json,subprocess,time
from pathlib import Path
sp=Path('/var/tmp/arc-scratch/uos-editor-selection-current.json');s=json.loads(sp.read_text())
root=Path(s.get('vice_retry_root',s['observer_root']));jobs=root.with_name(root.name+'-vice-jobs');jobs.mkdir()
s['vice_runs'].append(dict(label='vice64',root=str(root),jobs=str(jobs)));sp.write_text(json.dumps(s,indent=2)+'\n')
command=['/home/marc/.venvs/uos-tests/bin/python3','-B','tests/ci_native_pointer_iec.py','--editor-only','--editor-selection',
    '--editor-large','--80col','--vdc64','--d81','--reu-kib','512']
status=dict(label='vice64',cwd=str(root),command=command,started=time.time())
with (jobs/'vice64.log').open('w') as out:
 p=subprocess.Popen(command,cwd=root,stdout=out,stderr=subprocess.STDOUT);status['pid']=p.pid
 (jobs/'vice64.status.json').write_text(json.dumps(status,indent=2)+'\n');status['exit_code']=p.wait()
status['finished']=time.time();(jobs/'vice64.status.json').write_text(json.dumps(status,indent=2)+'\n')
(jobs/'complete.json').write_text(json.dumps([status],indent=2)+'\n')
print('vice64',status['exit_code']);raise SystemExit(int(status['exit_code']!=0))
