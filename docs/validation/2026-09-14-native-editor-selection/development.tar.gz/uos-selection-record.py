import gzip,hashlib,io,json,shutil,subprocess,tarfile,tempfile
from pathlib import Path
SP=Path('/var/tmp/arc-scratch/uos-editor-selection-current.json')
s=json.loads(SP.read_text());candidate=Path(s['candidate']);repo=Path('/home/marc/geos128/uos')
out=candidate/'docs/validation/2026-09-14-native-editor-selection'
assert not (out/'SHA256SUMS').exists(),'sealed records are immutable'
out.mkdir(parents=True,exist_ok=True)
digest=lambda b:hashlib.sha256(b).hexdigest()
def dump(name,value):(out/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def manifest(root):return {p.relative_to(root).as_posix():digest(p.read_bytes()) for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and 'docs/validation/' not in p.relative_to(root).as_posix()}
def archive(name,files):
    table={}
    with (out/(name+'.tar.gz')).open('wb') as raw:
        with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
            with tarfile.open(fileobj=gz,mode='w') as tar:
                for key,value in sorted(files.items()):
                    data=value.read_bytes() if isinstance(value,Path) else value
                    item=tarfile.TarInfo(key);item.size=len(data);item.mode=0o644
                    tar.addfile(item,io.BytesIO(data));table[key]=dict(bytes=len(data),sha256=digest(data))
    dump(name+'-files.json',table);print('archived',name,len(files),flush=True)
def terminal(pid):
    p=Path('/proc')/str(pid)/'stat'
    return not p.exists() or p.read_text().split()[2]=='Z'

root=Path(tempfile.mkdtemp(prefix='uos-selection-inputs-',dir=SP.parent))
shutil.copytree(candidate,root,dirs_exist_ok=True,ignore=lambda p,n:['validation'] if Path(p).name=='docs' else ['__pycache__'] if '__pycache__' in n else [])
inputs=manifest(root)
runtime={p:h for p,h in inputs.items() if not p.startswith(('docs/','tests/')) and not p.endswith('.md')}
executions={};statuses={};jobfiles={};outputs={};blobs={};cases=0
for generation,run in enumerate(s['qualification_runs']):
    folder=Path(run['jobs']);execution_root=Path(run['root'])
    initial=json.loads((folder/'inputs.json').read_text())
    initial={p:h for p,h in initial.items() if '__pycache__' not in Path(p).parts}
    assert manifest(execution_root)==initial
    assert all(initial.get(p)==h for p,h in runtime.items())
    labels=run.get('labels') or [json.loads(p.read_text())['label'] for p in sorted(folder.glob('*.status.json'))]
    executions[f'cpu-{generation+1}']=dict(root=str(execution_root),inputs=initial,jobs=labels)
    for p,h in initial.items():
        if inputs.get(p)!=h:blobs[h]=execution_root/p
    for name in labels:
        status=json.loads((folder/(name+'.status.json')).read_text());report=json.loads((folder/(name+'.json')).read_text())
        assert status['exit_code']==0 and terminal(status['pid']) and report['passed'] and report['physical_hardware_io'] is False,name
        assert status['cwd']==str(execution_root) and name not in statuses
        statuses[name]=status;cases+=len(report['cases'])
        for suffix,source in [('status.json','status.json'),('report.json','json'),('log','log')]:jobfiles[name+'.'+suffix]=folder/(name+'.'+source)
cpu_jobs=len(statuses);assert cpu_jobs==22
processes=subprocess.check_output(['ps','-eo','pid,ppid,stat,args'],text=True)
for run in s['vice_runs']:
    name=run['label'];execution_root=Path(run['root']);initial=manifest(execution_root)
    assert all(initial.get(p)==h for p,h in runtime.items())
    executions[name]=dict(root=str(execution_root),inputs=initial,jobs=[name])
    for p,h in initial.items():
        if inputs.get(p)!=h:blobs[h]=execution_root/p
    folder=Path(run['jobs']);status=json.loads((folder/(name+'.status.json')).read_text())
    assert status['exit_code']==0 and terminal(status['pid']) and status['cwd']==str(execution_root)
    log=folder/(name+'.log');result=Path(log.read_text().split('Native pointer VICE: ')[1].splitlines()[0])
    report=json.loads((result/'report.json').read_text())
    assert report['passed'] and report['all_host_processes_terminal'] and report['physical_hardware_io'] is False
    assert not any(str(result) in line for line in processes.splitlines())
    assert not any('Xvfb '+report['private_x_display']+' ' in line for line in processes.splitlines())
    statuses[name]=status;jobfiles[name+'.status.json']=folder/(name+'.status.json');jobfiles[name+'.log']=log
    outputs.update({name+'/'+p.relative_to(result).as_posix():p for p in result.rglob('*') if p.is_file()})
    if name=='vice64':shutil.copyfile(result/'editor-mouse-selection.png',out/'editor-selection.png')

build=json.loads(Path(s['rebuild_report']).read_text());assert build['passed'] and len(build['images'])==34
rebuilt=Path(s['rebuild_root'])
assert all(v['candidate']==v['rebuild']==inputs[p]==digest((rebuilt/p).read_bytes()) for p,v in build['images'].items())
jobfiles['build.json']=Path(s['rebuild_report']);jobfiles['build.log']=Path(s['rebuild_log'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==s['base']
subprocess.run(['git','diff','--quiet','HEAD','--'],cwd=repo,check=True)
assert all(digest((repo/p).read_bytes())==h for p,h in s['protected'].items())
assert digest((repo/s['previous_record']/'SHA256SUMS').read_bytes())==s['previous_seal']
subprocess.run(['git','verify-commit',s['base']],cwd=repo,check=True,capture_output=True)
tracked=set(subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0'))
new={'src/native/editor/selection.inc','src/native/editor/selection-state.inc','src/native/editor/selection-macros.inc','tests/ci_native_editor_selection.py'}
selected=[p for p in inputs if (p in tracked or p in new) and not p.startswith('target/')]
selected += ['target/native-desktop/'+n for n in ('editor.prg','editor.lst','editor-pack.sym','editor-pack.lst',
    'edpick.prg','edfind.prg','uos128.d64','uos128.d81','workspace.d64','workspace.d81','images.json','deployment.json')]
selected.append('target/native/editor.lst')
changes={}
for p in selected:
    old=digest((repo/p).read_bytes()) if (repo/p).exists() else None
    if old!=inputs[p]:changes[p]=dict(before=old,after=inputs[p])
assert set(changes).isdisjoint(s['protected'])
dump('changes.json',changes);dump('executions.json',executions);dump('jobs.json',statuses)
archive('inputs',{p:root/p for p in inputs});archive('execution-blobs',blobs)
archive('jobs',jobfiles);archive('outputs',outputs)
archive('rebuilt-images',{p:rebuilt/p for p in build['images']})
archive('parent-images',{p:repo/p for p in build['images']})
archive('parent-changes',{p:repo/p for p,v in changes.items() if v['before'] is not None})
development={p.name:p for p in SP.parent.glob('uos-selection-*') if p.is_file() and p.suffix in ('.json','.log','.py')}
development['state-before-archive.json']=SP
dev_runs=s.get('development',[])+s.get('superseded_qualification',[])
for number,run in enumerate(dev_runs):
    for key in ('jobs','extra_jobs'):
        if key not in run:continue
        folder=Path(run[key])
        for p in folder.glob('*'):
            if p.is_file():development[f'run-{number+1}-{key}/'+p.name]=p
for number,run in enumerate(s.get('superseded_vice_runs',[])):
    for p in Path(run['jobs']).glob('*'):
        if p.is_file():development[f'vice-superseded-{number+1}/'+p.name]=p
for number,run in enumerate(s['qualification_runs']):
    if 'labels' not in run:continue
    folder=Path(run['jobs'])
    for p in folder.glob('*.status.json'):
        label=json.loads(p.read_text())['label']
        if label in run['labels']:continue
        for suffix in ('status.json','json','log'):
            file=folder/(label+'.'+suffix)
            if file.exists():development[f'excluded-{number+1}/'+file.name]=file
for number,run in enumerate(s.get('vice_development',[])+s.get('development_vice_final9',[])):
    result=Path(run.get('result') or Path(run['log']).read_text().split('Native pointer VICE: ')[1].splitlines()[0])
    for p in result.glob('*'):
        if p.name in ('report.json','run.py','failure.png','failure-editor-ram.bin','failure-editor-workspace.bin','vice.log'):
            development[f'vice-development-{number+1}/'+p.name]=p
archive('development',development)
rom=Path('/usr/share/vice/C128/kernal-318020-05.bin')
dump('provenance.json',dict(base=s['base'],previous_seal=s['previous_seal'],physical_hardware_io=False,
    base_signature='G phoenix-agent@2acrestudios.com',processes_terminal_at_archival=True,
    inputs=inputs,runtime_inputs=runtime,runtime_identity=digest(json.dumps(runtime,sort_keys=True).encode()),
    cpu_jobs=cpu_jobs,cpu_cases=cases,vice_jobs=2,independent_builds=1,
    execution_storage='Final input bytes are reused by path/hash. Other execution inputs are stored by SHA256.',
    kernal_rom=dict(name=rom.name,sha256=digest(rom.read_bytes()),redistributed=False),
    tools={name:subprocess.run(cmd,text=True,capture_output=True,check=True).stdout.splitlines()[0] for name,cmd in {
        'cc':['cc','--version'],'64tass':['64tass','--version'],'x128':['x128','--version'],
        'python':['python3','--version'],'cpu-python':['/home/marc/.venvs/uos-tests/bin/python3','--version']}.items()}))
shutil.copyfile(SP.parent/'uos-selection-verify.py',out/'verify.py')
s.update(frozen=str(root),record=str(out),apply_input_paths=sorted(changes),cpu_cases=cases,stage='Qualification archived; offline audit and seal pending')
SP.write_text(json.dumps(s,indent=2)+'\n')
print(json.dumps(dict(record=str(out),changes=len(changes),inputs=len(inputs),cases=cases),indent=2))
