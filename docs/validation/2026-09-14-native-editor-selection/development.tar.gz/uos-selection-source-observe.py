import json,sys
from pathlib import Path
root=Path('/var/tmp/arc-scratch/uos-selection-release-73nkaxnm')
sys.path[:0]=[str(root/'tests'),str(root)]
from ci_native_editor_gui import GraphicalEditor
raw=(b'0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZ\r\n'*1800)[:66053]
files={(9,b'SOURCE',b'S'):b'ONE "QUOTE"\r\nTWO\n'+bytes([0,255]),(9,b'LARGE',b'S'):raw}
e=GraphicalEditor(files,source_path=b'/Apps/Original/EDITOR',source_context=2,device=9,fmt=0)
def opened():return [c.hex() for c in e.ultimate.commands if c[1]==2]
print('initial',opened(),flush=True)
e.type('ORIGINAL SOURCE');e.key(0x86);e.type('COPY');e.key(0x88);e.type('D10');e.key(13);e.type('S')
e.check(b'ORIGINAL SOURCE',15,True,mode=2)
print('picker returned',opened(),flush=True)
print('storage',e.value('dm_mode'),e.value('dm_lease'),flush=True)
e.key(27);e.exit(dirty=True);e.restored()
