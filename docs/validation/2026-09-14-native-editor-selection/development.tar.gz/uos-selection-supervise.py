import concurrent.futures,hashlib,json,subprocess,sys,time
from pathlib import Path
spec=json.loads(Path(sys.argv[1]).read_text());root=Path(spec['root']);jobs=Path(spec['jobs']);jobs.mkdir(exist_ok=True)
def run(item):
    label=item['label'];command=['/home/marc/.venvs/uos-tests/bin/python3','-B',*item['args'],'--report',str(jobs/(label+'.json'))]
    started=time.time()
    with (jobs/(label+'.log')).open('wb') as out:
        p=subprocess.Popen(command,cwd=root,stdout=out,stderr=subprocess.STDOUT)
        status=dict(label=label,pid=p.pid,cwd=str(root),command=command,started=started)
        (jobs/(label+'.status.json')).write_text(json.dumps(status,indent=2)+'\n')
        code=p.wait()
    status.update(exit_code=code,finished=time.time())
    (jobs/(label+'.status.json')).write_text(json.dumps(status,indent=2)+'\n')
    print(label,code,flush=True)
    return status
with concurrent.futures.ThreadPoolExecutor(max_workers=spec.get('workers',3)) as pool:results=list(pool.map(run,spec['tests']))
(jobs/'complete.json').write_text(json.dumps(results,indent=2)+'\n')
sys.exit(int(any(r['exit_code'] for r in results)))
