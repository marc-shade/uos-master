import concurrent.futures,json,subprocess,time
from pathlib import Path
sp=Path('/var/tmp/arc-scratch/uos-editor-selection-current.json');s=json.loads(sp.read_text())
root=Path(s['final_root']);jobs=root.with_name(root.name+'-vice-jobs');jobs.mkdir()
s.update(vice_root=str(root),vice_jobs=str(jobs));sp.write_text(json.dumps(s,indent=2)+'\n')
def run(label,extra):
 command=['/home/marc/.venvs/uos-tests/bin/python3','-B','tests/ci_native_pointer_iec.py','--editor-only','--editor-selection',*extra]
 status=dict(label=label,cwd=str(root),command=command,started=time.time())
 with (jobs/(label+'.log')).open('w') as out:
  p=subprocess.Popen(command,cwd=root,stdout=out,stderr=subprocess.STDOUT);status['pid']=p.pid
  (jobs/(label+'.status.json')).write_text(json.dumps(status,indent=2)+'\n')
  status['exit_code']=p.wait()
 status['finished']=time.time();(jobs/(label+'.status.json')).write_text(json.dumps(status,indent=2)+'\n')
 print(label,status['exit_code'],flush=True);return status
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 results=list(pool.map(lambda item:run(*item),[('vice16',[]),('vice64',['--editor-large','--80col','--vdc64','--d81','--reu-kib','512'])]))
(jobs/'complete.json').write_text(json.dumps(results,indent=2)+'\n');raise SystemExit(int(any(r['exit_code'] for r in results)))
