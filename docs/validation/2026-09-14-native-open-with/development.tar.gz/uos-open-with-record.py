import gzip,hashlib,io,json,shutil,subprocess,tarfile,tempfile
from pathlib import Path
SP=Path('/var/tmp/arc-scratch/uos-open-with-current.json')
s=json.loads(SP.read_text());candidate=Path(s['root']);repo=Path('/home/marc/geos128/uos')
out=candidate/'docs/validation/2026-09-14-native-open-with'
assert not (out/'SHA256SUMS').exists(),'sealed records are immutable'
out.mkdir(parents=True,exist_ok=True)
digest=lambda b:hashlib.sha256(b).hexdigest()
def dump(name,value):(out/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def manifest(root,keys):return {p:digest((root/p).read_bytes()) for p in keys}
def archive(name,files):
    table={}
    with (out/(name+'.tar.gz')).open('wb') as raw:
        with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
            with tarfile.open(fileobj=gz,mode='w') as tar:
                for key,value in sorted(files.items()):
                    data=value.read_bytes() if isinstance(value,Path) else value
                    item=tarfile.TarInfo(key);item.size=len(data);item.mode=0o644
                    tar.addfile(item,io.BytesIO(data));table[key]=dict(bytes=len(data),sha256=digest(data))
    dump(name+'-files.json',table);print('archived',name,len(files),flush=True)
def terminal(pid):
    p=Path('/proc')/str(pid)/'stat'
    return not p.exists() or p.read_text().split()[2]=='Z'
qualified=Path(s['qualification_root'])
keys=json.loads(Path(str(qualified)+'-inputs.json').read_text())
root=Path(tempfile.mkdtemp(prefix='uos-open-with-inputs-',dir=SP.parent))
for p in keys:
    source=candidate/p if p.endswith('.md') else qualified/p
    target=root/p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
inputs=manifest(root,keys)
runtime={p:h for p,h in inputs.items() if not p.startswith(('docs/','tests/')) and not p.endswith('.md')}
executions={};statuses={};jobfiles={};outputs={};blobs={};cases=0;cpu_jobs=0;vice_jobs=0
processes=subprocess.check_output(['ps','-eo','pid,ppid,stat,args'],text=True)
for generation,run in enumerate(s['qualification_runs']):
    folder=Path(run['jobs']);execution_root=Path(run['root'])
    initial=json.loads((folder/'inputs.json').read_text());assert manifest(execution_root,initial)==initial
    assert all(initial.get(p)==h for p,h in runtime.items()),str(execution_root)
    labels=run.get('labels') or [json.loads(p.read_text())['label'] for p in sorted(folder.glob('*.status.json'))]
    ordinary=[]
    for p,h in initial.items():
        if inputs.get(p)!=h:blobs[h]=execution_root/p
    for name in labels:
        status=json.loads((folder/(name+'.status.json')).read_text());log=folder/(name+'.log')
        assert status['exit_code']==0 and terminal(status['pid']) and status['cwd']==str(execution_root),name
        assert name not in statuses;statuses[name]=status
        jobfiles[name+'.status.json']=folder/(name+'.status.json');jobfiles[name+'.log']=log
        if name.startswith('vice'):
            result=Path(log.read_text().split('Native pointer VICE: ')[1].splitlines()[0]);report=json.loads((result/'report.json').read_text())
            assert report['passed'] and report['all_host_processes_terminal'] and report['physical_hardware_io'] is False
            assert report['xvfb_terminal'] and terminal(report['private_x_pid'])
            assert not any(str(result) in line for line in processes.splitlines())
            assert not any('Xvfb '+report['private_x_display']+' ' in line for line in processes.splitlines())
            outputs.update({name+'/'+p.relative_to(result).as_posix():p for p in result.rglob('*') if p.is_file()})
            executions[name]=dict(root=str(execution_root),inputs=initial,jobs=[name]);vice_jobs+=1
            if name=='vice64':shutil.copyfile(result/'open-with-editor.png',out/'open-with-editor.png')
        else:
            report=json.loads((folder/(name+'.json')).read_text());assert report['passed'],name
            assert report.get('physical_hardware_io',False) is False,name
            cases+=len(report.get('cases',[]));cpu_jobs+=1;ordinary.append(name)
            jobfiles[name+'.report.json']=folder/(name+'.json')
    if ordinary:executions[f'cpu-{generation+1}']=dict(root=str(execution_root),inputs=initial,jobs=ordinary)
assert vice_jobs==2 and cpu_jobs==34,(vice_jobs,cpu_jobs)
build=json.loads(Path(s['rebuild_report']).read_text());assert build['passed'] and len(build['images'])==36
rebuilt=Path(s['rebuild_root'])
assert all(v['candidate']==v['rebuild']==inputs[p]==digest((rebuilt/p).read_bytes()) for p,v in build['images'].items())
jobfiles['build.json']=Path(s['rebuild_report']);jobfiles['build.log']=Path(s['rebuild_log'])
jobfiles['candidate-build.log']=SP.parent/'uos-open-with-q4-build.log'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==s['parent']
subprocess.run(['git','diff','--quiet','HEAD','--'],cwd=repo,check=True)
assert all(digest((repo/p).read_bytes())==h for p,h in s['protected'].items())
assert all(digest((repo/p).read_bytes())==h for p,h in s['seals'].items())
subprocess.run(['git','verify-commit',s['parent']],cwd=repo,check=True,capture_output=True)
changes={}
for p in sorted(inputs):
    old=digest((repo/p).read_bytes()) if (repo/p).exists() else None
    if old!=inputs[p]:changes[p]=dict(before=old,after=inputs[p])
assert set(changes).isdisjoint(s['protected'])
dump('changes.json',changes);dump('executions.json',executions);dump('jobs.json',statuses)
archive('inputs',{p:root/p for p in inputs});archive('execution-blobs',blobs)
archive('jobs',jobfiles);archive('outputs',outputs)
archive('rebuilt-images',{p:rebuilt/p for p in build['images']})
archive('parent-images',{p:repo/p for p in build['images'] if (repo/p).exists()})
archive('parent-changes',{p:repo/p for p,v in changes.items() if v['before'] is not None})
development={p.name:p for p in SP.parent.glob('uos-open-with-*') if p.is_file() and p.suffix in ('.json','.log','.py')}
development['state-before-archive.json']=SP
folders={Path(p) for p in s['development_runs']}|{Path(r['jobs']) for r in s.get('superseded_runs',[])}
for folder in sorted(folders):
    development.update({folder.name+'/'+p.name:p for p in folder.iterdir() if p.is_file()})
    for p in folder.glob('vice*.log'):
        text=p.read_text()
        if 'Native pointer VICE: ' not in text:continue
        result=Path(text.split('Native pointer VICE: ')[1].splitlines()[0]);r=json.loads((result/'report.json').read_text())
        assert r['all_host_processes_terminal'] and r['xvfb_terminal']
        for item in result.rglob('*'):
            if item.is_file():development['excluded-'+result.name+'/'+item.relative_to(result).as_posix()]=item
for run in s['qualification_runs']:
    if 'labels' not in run:continue
    folder=Path(run['jobs'])
    for p in folder.glob('*.status.json'):
        name=json.loads(p.read_text())['label']
        if name in run['labels']:continue
        for suffix in ('status.json','json','log'):
            item=folder/(name+'.'+suffix)
            if item.exists():development['excluded-'+folder.name+'/'+item.name]=item
        if name.startswith('vice'):
            log=(folder/(name+'.log')).read_text()
            result=Path(log.split('Native pointer VICE: ')[1].splitlines()[0])
            report=json.loads((result/'report.json').read_text())
            assert report['all_host_processes_terminal'] and report['xvfb_terminal']
            for item in result.rglob('*'):
                if item.is_file():development['excluded-'+result.name+'/'+item.relative_to(result).as_posix()]=item
versions={}
for run in s.get('superseded_runs',[]):
    execution_root=Path(run['root']);initial=json.loads((Path(run['jobs'])/'inputs.json').read_text())
    assert manifest(execution_root,initial)==initial
    changed={p:h for p,h in initial.items() if inputs.get(p)!=h};versions[str(execution_root)]=changed
    for p,h in changed.items():development['versions/'+h]=execution_root/p
# Earlier smoke inputs have their own command/manifest records where retained;
# their logs and reported failures are excluded from selected qualification.
development['versions.json']=(json.dumps(versions,indent=2,sort_keys=True)+'\n').encode()
archive('development',development)
rom=Path('/usr/share/vice/C128/kernal-318020-05.bin')
dump('provenance.json',dict(base=s['parent'],previous_seal=s['seals']['docs/validation/2026-09-14-native-editor-history/SHA256SUMS'],physical_hardware_io=False,
    base_signature='G phoenix-agent@2acrestudios.com',processes_terminal_at_archival=True,
    inputs=inputs,runtime_inputs=runtime,runtime_identity=digest(json.dumps(runtime,sort_keys=True).encode()),
    cpu_jobs=cpu_jobs,cpu_cases=cases,vice_jobs=vice_jobs,independent_builds=1,
    execution_storage='Final input bytes are reused by path/hash. Other execution inputs are stored by SHA256.',
    input_scope='Tracked nonvalidation inputs plus eight declared new paths; generated Claude intermediates and Python caches excluded.',
    preserved_prior_seals=s['seals'],protected_paths=s['protected'],
    kernal_rom=dict(name=rom.name,sha256=digest(rom.read_bytes()),redistributed=False),
    tools={name:subprocess.run(cmd,text=True,capture_output=True,check=True).stdout.splitlines()[0] for name,cmd in {
        'cc':['cc','--version'],'64tass':['64tass','--version'],'x128':['x128','--version'],
        'python':['python3','--version'],'cpu-python':['/home/marc/.venvs/uos-tests/bin/python3','--version']}.items()}))
shutil.copyfile(SP.parent/'uos-open-with-verify.py',out/'verify.py')
s.update(frozen=str(root),record=str(out),apply_input_paths=sorted(changes),cpu_cases=cases,stage='Qualification archived; offline audit and seal pending')
SP.write_text(json.dumps(s,indent=2)+'\n')
print(json.dumps(dict(record=str(out),changes=len(changes),inputs=len(inputs),cases=cases),indent=2))
