import hashlib,json,shutil,subprocess
from pathlib import Path
sp=Path('/var/tmp/arc-scratch/uos-open-with-current.json');s=json.loads(sp.read_text())
repo=Path(s['repo']);record=Path(s['record']);frozen=Path(s['frozen']);digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.run(['git',*args],cwd=repo,check=True,text=True,capture_output=True)
assert not s['applied'] and git('rev-parse','HEAD').stdout.strip()==s['parent']
git('diff','--quiet','HEAD','--');git('verify-commit',s['parent'])
assert all(digest(repo/p)==h for p,h in s['protected'].items())
assert all(digest(repo/p)==h for p,h in s['seals'].items())
checks=json.loads((record/'audit.json').read_text());assert checks['passed'] and checks['jobs']==36 and checks['images']==36
assert checks['modules']['fspick']['end']==0xc000
seals={line.split('  ',1)[1]:line.split('  ',1)[0] for line in (record/'SHA256SUMS').read_text().splitlines()}
assert set(seals)=={p.name for p in record.iterdir() if p.is_file() and p.name!='SHA256SUMS'}
assert all(digest(record/p)==h for p,h in seals.items())
changes=json.loads((record/'changes.json').read_text());assert set(changes).isdisjoint(s['protected'])
for p,change in changes.items():
    assert '..' not in Path(p).parts and not Path(p).is_absolute() and not p.startswith('docs/validation/')
    assert digest(frozen/p)==change['after']
    assert (digest(repo/p) if (repo/p).exists() else None)==change['before']
dest=repo/'docs/validation'/record.name;assert not dest.exists()
for p in changes:
    (repo/p).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(frozen/p,repo/p)
shutil.copytree(record,dest)
assert all(digest(repo/p)==v['after'] for p,v in changes.items())
assert all(digest(repo/p)==h for p,h in s['protected'].items())
assert all(digest(repo/p)==h for p,h in s['seals'].items())
s.update(applied=True,record_in_repo=str(dest),stage='Applied qualified native document launch; signed local commit pending')
sp.write_text(json.dumps(s,indent=2)+'\n')
paths=sorted(changes)+[p.relative_to(repo).as_posix() for p in sorted(dest.iterdir()) if p.is_file()]
(sp.parent/'uos-open-with-stage-paths.txt').write_text('\n'.join(paths)+'\n')
print(json.dumps(dict(applied=True,changed_files=len(changes),record=str(dest),seal=digest(dest/'SHA256SUMS')),indent=2))
